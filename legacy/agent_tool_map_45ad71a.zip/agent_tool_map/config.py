#!/usr/bin/env python3
"""
Configuration file for the Map Agent Tool
Centralized configuration for all model and system settings
"""

# =============================================================================
# AI MODEL CONFIGURATION
# =============================================================================

# Primary LLM model for natural language processing and query understanding
PRIMARY_MODEL = "gemma3:12b"

# Model parameters
MODEL_TEMPERATURE = 0.1  # Low temperature for consistent, deterministic responses
MODEL_MAX_TOKENS = 2048  # Maximum tokens for model responses

# Fallback models (in order of preference)
FALLBACK_MODELS = [
    "gemma3:27b",      # Larger Gemma model
    "qwen2.5:32b",     # Alternative large model
    "gpt-oss:20b",     # Original model (for backward compatibility)
]

# =============================================================================
# OSM AND GEOSPATIAL CONFIGURATION
# =============================================================================

# OSM Overpass API settings
OSM_API_BASE_URL = "https://overpass-api.de/api/interpreter"
OSM_REQUEST_TIMEOUT = 60  # seconds
OSM_RATE_LIMIT_DELAY = 1.0  # seconds

# Caching configuration
CACHE_DIR = "cache"
CACHE_ENABLED = True
CACHE_TTL_HOURS = 24  # Cache expiration time

# Geospatial settings
DEFAULT_H3_RESOLUTION = 9  # H3 resolution for heatmap analysis
EARTH_RADIUS_METERS = 6371000  # Earth's radius for distance calculations

# Analysis parameters
MAX_HOTELS_ANALYZE = 20
MAX_ATTRACTIONS_ANALYZE = 30
MAX_SCHOOLS_ANALYZE = 50
MAX_METRO_STATIONS_ANALYZE = 50
MAX_SHOPPING_CENTERS_ANALYZE = 20
MAX_RESIDENTIAL_BUILDINGS_ANALYZE = 100
MAX_COMPETITORS_ANALYZE = 50
MAX_TRAFFIC_ATTRACTORS_ANALYZE = 100

# Distance thresholds for analysis (in meters)
DEFAULT_MAX_DISTANCE = 1000
WALKING_DISTANCE_THRESHOLD = 2000

# =============================================================================
# VISUALIZATION CONFIGURATION
# =============================================================================

# Results and output settings
RESULTS_DIR = "results"  # Main results directory
RESULTS_SUBDIRS = {
    'hotel': 'hotel',           # Hotel analysis results
    'residential': 'residential',  # Residential analysis results
    'business': 'business'      # Business analysis results
}

# Folium map settings
DEFAULT_MAP_ZOOM = 13
DEFAULT_MAP_TILES = "OpenStreetMap"

# Color schemes for different POI types
COLOR_SCHEME = {
    'hotels': '#FF6B6B',          # Red
    'attractions': '#4ECDC4',     # Teal
    'schools': '#45B7D1',         # Blue
    'metro_stations': '#96CEB4',  # Green
    'shopping_centers': '#FECA57', # Yellow
    'residential': '#FF9FF3',     # Pink
    'competitors': '#FF3838',     # Dark red
    'attractors': '#48DBFB',      # Light blue
}

# Heatmap color gradients
HEATMAP_GRADIENT = {
    0.2: '#00FF00',   # Green (low)
    0.5: '#FFFF00',   # Yellow (medium)
    0.8: '#FF0000',   # Red (high)
    1.0: '#8B0000'    # Dark red (very high)
}

# =============================================================================
# LOGGING CONFIGURATION
# =============================================================================

# Logging settings
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOG_FILE = "map_agent.log"

# =============================================================================
# BUSINESS ANALYSIS CONFIGURATION
# =============================================================================

# Business type mappings to OSM tags
BUSINESS_TYPE_MAPPING = {
    'cafe': 'amenity=cafe',
    'restaurant': 'amenity=restaurant',
    'coffee': 'amenity=cafe',
    'shop': 'shop=*',
    'retail': 'shop=*',
    'grocery': 'shop=supermarket',
    'mall': 'shop=mall',
    'office': 'building=office',
}

# Traffic attractor types (OSM tags)
TRAFFIC_ATTRACTOR_TAGS = [
    "railway=station",           # Train stations
    "tourism=attraction",        # Tourist attractions
    "tourism=museum",           # Museums
    "tourism=viewpoint",        # Viewpoints
    "shop=mall",               # Shopping malls
    "shop=department_store",   # Department stores
    "building=office",         # Office buildings
    "amenity=university",      # Universities
    "amenity=school",          # Schools (high traffic)
]

# Business scoring weights
BUSINESS_SCORING_WEIGHTS = {
    'traffic_score': 1.0,       # Weight for traffic attractors
    'competition_penalty': 0.5, # Weight for competitors (negative)
    'base_score': 0.1,         # Minimum base score
    'min_optimal_score': 0.2,   # Minimum score to be considered optimal
}

# =============================================================================
# RESIDENTIAL ANALYSIS CONFIGURATION
# =============================================================================

# Residential amenity weights
RESIDENTIAL_WEIGHTS = {
    'schools': 0.3,        # Education importance
    'metro': 0.4,         # Transportation importance
    'shopping': 0.3,      # Shopping convenience importance
}

# Residential building types to search for
RESIDENTIAL_BUILDING_TYPES = [
    "apartments",
    "residential",
    "house",
    "terrace",
    "detached",
    "semidetached",
]

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def get_model_config():
    """Get the current model configuration"""
    return {
        'model_name': PRIMARY_MODEL,
        'temperature': MODEL_TEMPERATURE,
        'max_tokens': MODEL_MAX_TOKENS,
        'fallback_models': FALLBACK_MODELS,
    }

def get_osm_config():
    """Get OSM configuration"""
    return {
        'api_url': OSM_API_BASE_URL,
        'timeout': OSM_REQUEST_TIMEOUT,
        'rate_limit_delay': OSM_RATE_LIMIT_DELAY,
        'cache_dir': CACHE_DIR,
        'cache_enabled': CACHE_ENABLED,
    }

def get_business_types():
    """Get available business type mappings"""
    return BUSINESS_TYPE_MAPPING.copy()

def get_color_scheme():
    """Get the color scheme for visualizations"""
    return COLOR_SCHEME.copy()

# =============================================================================
# VALIDATION FUNCTIONS
# =============================================================================

def validate_config():
    """Validate configuration settings"""
    errors = []

    # Check model configuration
    if not PRIMARY_MODEL:
        errors.append("PRIMARY_MODEL must be set")

    if not (0 <= MODEL_TEMPERATURE <= 2.0):
        errors.append("MODEL_TEMPERATURE must be between 0 and 2.0")

    # Check OSM configuration
    if OSM_REQUEST_TIMEOUT <= 0:
        errors.append("OSM_REQUEST_TIMEOUT must be positive")

    if OSM_RATE_LIMIT_DELAY < 0:
        errors.append("OSM_RATE_LIMIT_DELAY must be non-negative")

    return errors

# Validate configuration on import
config_errors = validate_config()
if config_errors:
    print("Configuration validation errors:")
    for error in config_errors:
        print(f"  - {error}")
    raise ValueError("Invalid configuration")

# =============================================================================
# VERSION INFO
# =============================================================================

__version__ = "1.0.0"
__author__ = "Map Agent Tool"
__description__ = "Configuration file for centralized model and system settings"

# =============================================================================
# UTILITY FUNCTIONS FOR FILE PATHS
# =============================================================================

def generate_timestamped_filepath(base_name: str, theme: str, extension: str = "html") -> str:
    """
    Generate a timestamped filepath with theme-based organization.

    Args:
        base_name: Base filename without extension (e.g., "hotel_analysis")
        theme: Theme folder name (e.g., "hotel", "residential", "business")
        extension: File extension (default: "html")

    Returns:
        Complete filepath with timestamp suffix in theme subfolder
    """
    from datetime import datetime
    import os

    # Generate timestamp in format: YYYYMMDD_HHMMSS
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # Create filename with timestamp suffix
    filename = f"{base_name}_{timestamp}.{extension}"

    # Get theme subfolder from config
    theme_subdir = RESULTS_SUBDIRS.get(theme, theme)

    # Create theme-based subfolder path
    theme_path = os.path.join(RESULTS_DIR, theme_subdir)
    filepath = os.path.join(theme_path, filename)

    # Ensure the theme directory exists
    os.makedirs(theme_path, exist_ok=True)

    return filepath
