import hashlib
import json
import logging
import os
import time
import pickle
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Any, Union

import math
import overpy

from shapely.geometry import Point
from geopy.distance import geodesic
from geopy.geocoders import Nominatim

from config import (
    OSM_REQUEST_TIMEOUT, OSM_RATE_LIMIT_DELAY,
    CACHE_DIR, CACHE_ENABLED, CACHE_TTL_HOURS
)

logger = logging.getLogger(__name__)


@dataclass
class POI:
    """Point of Interest data structure with enhanced metadata"""
    id: str
    name: str
    lat: float
    lon: float
    tags: Dict[str, str]
    geometry: Point
    osm_type: str = "node"  # node, way, relation
    importance_score: float = 0.0
    search_relevance: float = 0.0
    category: str = ""
    subcategory: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Convert POI to dictionary for serialization"""
        return {
            'id': self.id,
            'name': self.name,
            'lat': self.lat,
            'lon': self.lon,
            'tags': self.tags,
            'osm_type': self.osm_type,
            'importance_score': self.importance_score,
            'search_relevance': self.search_relevance,
            'category': self.category,
            'subcategory': self.subcategory,
            'geometry_type': self.geometry.geom_type if self.geometry else None
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'POI':
        """Create POI from dictionary"""
        return cls(
            id=data['id'],
            name=data['name'],
            lat=data['lat'],
            lon=data['lon'],
            tags=data['tags'],
            geometry=Point(data['lon'], data['lat']),
            osm_type=data.get('osm_type', 'node'),
            importance_score=data.get('importance_score', 0.0),
            search_relevance=data.get('search_relevance', 0.0),
            category=data.get('category', ''),
            subcategory=data.get('subcategory', '')
        )


@dataclass
class CityBounds:
    """City geographical boundaries with enhanced metadata"""
    north: float
    south: float
    east: float
    west: float
    city_name: str = ""
    country: str = ""
    confidence_score: float = 1.0
    population: Optional[int] = None
    area_km2: Optional[float] = None

    @property
    def bbox(self) -> Tuple[float, float, float, float]:
        """Return bounding box as (south, west, north, east)"""
        return (self.south, self.west, self.north, self.east)

    @property
    def center(self) -> Tuple[float, float]:
        """Return center coordinates"""
        return ((self.north + self.south) / 2, (self.east + self.west) / 2)

    def calculate_area(self) -> float:
        """Calculate approximate area in square kilometers"""
        if self.area_km2:
            return self.area_km2

        lat_diff = self.north - self.south
        lon_diff = self.east - self.west
        lat_km = lat_diff * 111.0
        lon_km = lon_diff * 111.0 * abs((self.north + self.south) / 2)
        self.area_km2 = lat_km * lon_km
        return self.area_km2

    def contains_point(self, lat: float, lon: float) -> bool:
        """Check if point is within city bounds"""
        return (self.south <= lat <= self.north and
                self.west <= lon <= self.east)


@dataclass
class SearchQuery:
    """Structured search query"""
    raw_query: str
    parsed_terms: List[str]
    categories: List[str]
    location: Optional[str] = None
    bbox: Optional[Tuple[float, float, float, float]] = None
    limit: int = 100
    radius_km: Optional[float] = None
    filters: Dict[str, Any] = None
    intent: str = "search"
    visualization_type: str = "markers"
    analysis_type: Optional[str] = None
    confidence_score: float = 0.0

    def __post_init__(self):
        if self.filters is None:
            self.filters = {}

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for caching"""
        return {
            'raw_query': self.raw_query,
            'parsed_terms': self.parsed_terms,
            'categories': self.categories,
            'location': self.location,
            'bbox': self.bbox,
            'limit': self.limit,
            'radius_km': self.radius_km,
            'filters': self.filters,
            'intent': self.intent,
            'visualization_type': self.visualization_type,
            'analysis_type': self.analysis_type,
            'confidence_score': self.confidence_score
        }


@dataclass
class CacheEntry:
    """Cache entry with metadata and validation"""
    data: Any
    timestamp: datetime
    query_hash: str
    ttl_hours: int = CACHE_TTL_HOURS
    access_count: int = 0
    last_accessed: datetime = None

    def __post_init__(self):
        if self.last_accessed is None:
            self.last_accessed = self.timestamp

    def is_valid(self) -> bool:
        """Check if cache entry is still valid"""
        return datetime.now() - self.timestamp < timedelta(hours=self.ttl_hours)

    def mark_accessed(self):
        """Update access metadata"""
        self.access_count += 1
        self.last_accessed = datetime.now()


@dataclass
class SearchMetrics:
    """Performance and usage metrics for the search engine"""
    total_queries: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    api_requests: int = 0
    total_response_time: float = 0.0
    error_count: int = 0
    last_query_time: Optional[float] = None

    @property
    def cache_hit_rate(self) -> float:
        """Calculate cache hit rate percentage"""
        total = self.cache_hits + self.cache_misses
        return (self.cache_hits / total * 100) if total > 0 else 0.0

    @property
    def average_response_time(self) -> float:
        """Calculate average response time"""
        return self.total_response_time / self.total_queries if self.total_queries > 0 else 0.0


class OSMSearchEngine:
    """
    Advanced OpenStreetMap search engine optimized for AI agents.

    This engine provides intelligent search capabilities with:
    - Query optimization and parsing
    - Advanced caching system
    - Robust error handling
    - Performance monitoring
    - POI scoring and ranking
    - Multi-strategy location detection
    """

    def __init__(self, cache_dir: str = CACHE_DIR, cache_enabled: bool = CACHE_ENABLED):
        """Initialize the OSM Search Engine"""
        self.cache_dir = cache_dir
        self.cache_enabled = cache_enabled
        os.makedirs(cache_dir, exist_ok=True)

        # Initialize OSM API client
        self.api = overpy.Overpass()

        # Rate limiting and performance tracking
        self.last_request_time = 0.0
        self.min_request_interval = OSM_RATE_LIMIT_DELAY
        self.consecutive_errors = 0
        self.backoff_until = 0.0
        self.metrics = SearchMetrics()

        # Query settings
        self.max_retries = 3
        self.backoff_factor = 2.0
        self.max_backoff_time = 30.0
        self.default_timeout = OSM_REQUEST_TIMEOUT

        # Initialize geolocator for geocoding
        self.geolocator = Nominatim(user_agent="osm_search_engine")
        
        # Initialize coordinates cache
        self._coordinates_cache = {}

        logger.info("OSM Search Engine initialized successfully")


    def get_city_coordinates(self, city_name: str, country: Optional[str] = None) -> Optional[Tuple[float, float]]:
        """Get city coordinates using geocoding with caching"""
        cache_key = f"{city_name.lower()}_{country.lower()}" if country else city_name.lower()
        
        # Check cache first
        if cache_key in self._coordinates_cache:
            return self._coordinates_cache[cache_key]

        # Try geocoding
        try:
            query = f"{city_name}, {country}" if country else city_name
            location = self.geolocator.geocode(query, timeout=10)
            
            if location:
                coords = (location.latitude, location.longitude)
                self._coordinates_cache[cache_key] = coords
                return coords
        except Exception as e:
            logger.warning(f"Geocoding failed for {city_name}: {e}")

        return None


    def _get_cache_key(self, query: str, params: Dict = None) -> str:
        """Generate enhanced cache key from query and parameters"""
        cache_data = {"query": query, "params": params or {}}
        cache_string = json.dumps(cache_data, sort_keys=True)
        return hashlib.sha256(cache_string.encode()).hexdigest()

    def _load_from_cache(self, cache_key: str) -> Optional[Any]:
        """Load result from cache with validation and metrics"""
        if not self.cache_enabled:
            return None

        cache_file = os.path.join(self.cache_dir, f"{cache_key}.pkl")

        if not os.path.exists(cache_file):
            return None

        try:
            with open(cache_file, 'rb') as f:
                cache_entry = pickle.load(f)

            if isinstance(cache_entry, CacheEntry) and cache_entry.is_valid():
                cache_entry.mark_accessed()
                # Update cache file with new access metadata
                with open(cache_file, 'wb') as f:
                    pickle.dump(cache_entry, f)

                self.metrics.cache_hits += 1
                logger.debug(f"Cache hit for key: {cache_key[:8]}...")
                return cache_entry.data
            else:
                # Remove invalid cache entry
                os.remove(cache_file)
                logger.debug(f"Removed invalid cache entry: {cache_key[:8]}...")

        except (pickle.UnpicklingError, EOFError, FileNotFoundError) as e:
            logger.warning(f"Failed to load cache entry, removing file: {e}")
            try:
                os.remove(cache_file)
            except OSError:
                pass
        except Exception as e:
            logger.warning(f"An unexpected error occurred while loading cache: {e}")

        return None

    def _save_to_cache(self, cache_key: str, data: Any, ttl_hours: int = CACHE_TTL_HOURS):
        """Save result to cache with metadata"""
        if not self.cache_enabled:
            return

        cache_file = os.path.join(self.cache_dir, f"{cache_key}.pkl")
        cache_entry = CacheEntry(
            data=data,
            timestamp=datetime.now(),
            query_hash=cache_key,
            ttl_hours=ttl_hours
        )

        try:
            with open(cache_file, 'wb') as f:
                pickle.dump(cache_entry, f)
            logger.debug(f"Cached result for key: {cache_key[:8]}...")
        except Exception as e:
            logger.warning(f"Failed to save cache: {e}")

    def _rate_limit(self):
        """Apply enhanced rate limiting with adaptive delays and backoff"""
        current_time = time.time()

        # Check if we're in a backoff period
        if current_time < self.backoff_until:
            sleep_time = self.backoff_until - current_time
            logger.warning(f"Rate limit backoff active. Sleeping for {sleep_time:.1f}s")
            time.sleep(sleep_time)

        # Apply normal rate limiting
        time_since_last = current_time - self.last_request_time
        if time_since_last < self.min_request_interval:
            sleep_time = self.min_request_interval - time_since_last
            logger.debug(f"Rate limit delay. Sleeping for {sleep_time:.2f}s")
            time.sleep(sleep_time)

        self.last_request_time = time.time()

    def _execute_query_with_retry(self, query: str) -> overpy.Result:
        """Execute Overpass query with retry logic and error handling"""
        cache_key = self._get_cache_key(query)

        # Try cache first
        if self.cache_enabled:
            cached_result = self._load_from_cache(cache_key)
            if cached_result:
                return cached_result

        self.metrics.cache_misses += 1

        # Execute query with enhanced retries and rate limiting
        last_exception = None
        for attempt in range(self.max_retries):
            try:
                self._rate_limit()

                logger.debug(f"Executing OSM query (attempt {attempt + 1}/{self.max_retries})")
                start_time = time.time()

                result = self.api.query(query)

                query_time = time.time() - start_time
                self.metrics.total_response_time += query_time
                self.metrics.last_query_time = query_time
                self.metrics.api_requests += 1

                # Reset consecutive errors on success
                self.consecutive_errors = 0

                # Cache the result
                if self.cache_enabled:
                    self._save_to_cache(cache_key, result)

                return result

            except Exception as e:
                last_exception = e
                self.metrics.error_count += 1
                self.consecutive_errors += 1

                error_msg = str(e).lower()

                # Handle rate limiting specifically
                if "too many requests" in error_msg or "rate limit" in error_msg:
                    logger.warning(f"Rate limit hit on attempt {attempt + 1}")

                    # Implement progressive backoff for rate limits
                    if self.consecutive_errors >= 3:
                        # Longer backoff for repeated rate limits
                        backoff_time = min(self.max_backoff_time, 30.0 * (2 ** (self.consecutive_errors - 3)))
                        self.backoff_until = time.time() + backoff_time
                        logger.warning(f"Extended backoff due to repeated rate limits: {backoff_time:.1f}s")
                        time.sleep(backoff_time)
                    else:
                        # Standard exponential backoff
                        delay = min(self.max_backoff_time, self.backoff_factor ** attempt * 2)
                        logger.debug(f"Rate limit backoff: {delay:.1f}s")
                        time.sleep(delay)

                elif "server load too high" in error_msg:
                    logger.warning(f"Server load too high on attempt {attempt + 1}")
                    # Longer delay for server load issues
                    delay = min(self.max_backoff_time, 15.0 * (attempt + 1))
                    logger.debug(f"Server load backoff: {delay:.1f}s")
                    time.sleep(delay)

                elif attempt < self.max_retries - 1:
                    # Standard exponential backoff for other errors
                    delay = min(self.max_backoff_time, self.backoff_factor ** attempt)
                    logger.debug(f"Retrying in {delay:.1f}s...")
                    time.sleep(delay)

                else:
                    logger.error(f"OSM query failed after {self.max_retries} attempts")
                    raise last_exception

    def parse_search_query(self, query: str) -> SearchQuery:
        """Parse natural language query into structured search parameters"""
        # Simple keyword-based parsing
        query_lower = query.lower()
        parsed_terms = [word for word in query.split() if len(word) > 2]
        
        # Extract categories from query
        categories = []
        category_keywords = {
            'hotels': ['hotel', 'hotels', 'accommodation', 'lodging'],
            'restaurants': ['restaurant', 'restaurants', 'food', 'dining', 'cafe', 'cafes'],
            'shops': ['shop', 'shops', 'shopping', 'store', 'stores', 'mall'],
            'attractions': ['attraction', 'attractions', 'museum', 'museums', 'monument', 'monuments'],
            'parks': ['park', 'parks', 'garden', 'gardens'],
            'transport': ['station', 'stations', 'bus', 'train', 'metro', 'airport'],
            'hospitals': ['hospital', 'hospitals', 'clinic', 'clinics', 'medical'],
            'banks': ['bank', 'banks', 'atm', 'atms'],
            'schools': ['school', 'schools', 'university', 'college', 'education']
        }
        
        for category, keywords in category_keywords.items():
            if any(keyword in query_lower for keyword in keywords):
                categories.append(category)
        
        # Default categories if none found
        if not categories:
            categories = ['restaurants', 'shops', 'attractions']
        
        # Extract location
        location = None
        location_keywords = ['in ', 'near ', 'around ', 'at ']
        for keyword in location_keywords:
            if keyword in query_lower:
                location_part = query_lower.split(keyword)[-1].strip()
                # Take first word as location (simple approach)
                location = location_part.split()[0].title()
                break
        
        # Get city bounds if location found
        bbox = None
        if location:
            city_bounds = self.get_city_bounds(location)
            if city_bounds:
                bbox = city_bounds.bbox

        return SearchQuery(
            raw_query=query,
            parsed_terms=parsed_terms,
            categories=categories,
            location=location,
            bbox=bbox,
            limit=50,
            intent='search',
            visualization_type='markers',
            confidence_score=0.8
        )


    def get_city_bounds(self, city_name: str) -> Optional[CityBounds]:
        """Get city bounds using coordinates and approximation"""
        # Get city coordinates
        coords = self.get_city_coordinates(city_name)
        if coords:
            lat, lon = coords
            return self._create_bounds_from_center(lat, lon, city_name, radius_km=15)
        
        return None


    def _create_bounds_from_center(self, lat: float, lon: float, city_name: str,
                                   radius_km: float) -> CityBounds:
        """Create bounds from center point and radius"""
        lat_offset = radius_km / 111.0  # 1 degree ≈ 111 km
        lon_offset = radius_km / (111.0 * abs(math.cos(math.radians(lat))))  # Adjust for latitude

        return CityBounds(
            north=lat + lat_offset,
            south=lat - lat_offset,
            east=lon + lon_offset,
            west=lon - lon_offset,
            city_name=city_name,
            confidence_score=0.8  # Medium confidence for approximation
        )


    def search_pois(self, query: Union[str, SearchQuery], limit: int = 100) -> List[POI]:
        """Main POI search method"""
        start_time = time.time()
        self.metrics.total_queries += 1

        try:
            # Parse query if it's a string
            if isinstance(query, str):
                search_query = self.parse_search_query(query)
            else:
                search_query = query

            # Determine search area
            bbox = search_query.bbox
            if not bbox and search_query.location:
                city_bounds = self.get_city_bounds(search_query.location)
                if city_bounds:
                    bbox = city_bounds.bbox

            if not bbox:
                # Default to Moscow if no location specified
                bbox = self._create_bounds_from_center(55.7558, 37.6176, "Moscow", 10).bbox

            # Execute OSM query
            effective_limit = min(limit, search_query.limit) if hasattr(search_query, 'limit') and search_query.limit else limit
            pois = self._execute_poi_search(bbox, search_query.categories, effective_limit)

            search_time = time.time() - start_time
            self.metrics.total_response_time += search_time

            logger.info(f"Found {len(pois)} POIs in {search_time:.2f}s")
            return pois[:limit]

        except Exception as e:
            self.metrics.error_count += 1
            logger.error(f"POI search failed: {e}")
            return []

    
    def _execute_poi_search(self, bbox: Tuple[float, float, float, float],
                            categories: List[str], limit: int) -> List[POI]:
        """
        Execute POI search with a single, optimized Overpass query for all categories.
        This method replaces the old logic that sent one request per tag.
        """
        if not categories:
            logger.warning("No categories provided for POI search.")
            return []

        # Map high-level categories to specific OSM tags
        category_tags_map = self._map_categories_to_tags(categories)
        
        all_tags = set()
        for cat_tags in category_tags_map.values():
            all_tags.update(cat_tags)

        if not all_tags:
            logger.warning("No valid OSM tags found for the given categories.")
            return []

        bbox_str = f"({bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]})"
        query_parts = []

        # Build query parts for each tag
        for tag in all_tags:
            if '=' in tag:
                key, value = tag.split('=', 1)
                tag_filter = f'["{key}"="{value}"]' if value != '*' else f'["{key}"]'
            else:
                tag_filter = f'["{tag}"]'
            
            query_parts.append(f'node{tag_filter}{bbox_str};')
            query_parts.append(f'way{tag_filter}{bbox_str};')
            query_parts.append(f'relation{tag_filter}{bbox_str};')

        # Join all parts into a single query with a union block
        full_query = f"""
        [out:json][timeout:{self.default_timeout}];
        (
          {''.join(query_parts)}
        );
        out center;
        """
        
        logger.info(f"Executing one combined Overpass query for {len(categories)} categories.")
        logger.debug(f"Overpass Query: {full_query[:500]}...") # Log beginning of query

        try:
            # Execute the single, combined query
            result = self._execute_query_with_retry(full_query)
            
            # Process all elements from the single result
            all_pois = self._process_osm_result(result, limit * 2)

            # Remove duplicates, as a POI might match multiple tags
            seen_ids = set()
            unique_pois = []
            for poi in all_pois:
                if poi.id not in seen_ids:
                    seen_ids.add(poi.id)
                    unique_pois.append(poi)

            logger.info(f"Found {len(unique_pois)} unique POIs from the combined query.")
            # Respect the limit parameter
            return unique_pois[:limit]

        except Exception as e:
            logger.error(f"Failed to execute combined POI search query: {e}")
            return []

    def _map_categories_to_tags(self, categories: List[str]) -> Dict[str, List[str]]:
        """Map search categories to OSM tags"""
        tag_mapping = {
            'hotels': ['tourism=hotel', 'tourism=hostel', 'tourism=guest_house'],
            'restaurants': ['amenity=restaurant', 'amenity=cafe', 'amenity=bar'],
            'schools': ['amenity=school', 'amenity=university', 'amenity=kindergarten'],
            'shops': ['shop=supermarket', 'shop=mall', 'shop=convenience'],
            'transport': ['railway=station', 'highway=bus_stop', 'amenity=parking'],
            'attractions': ['tourism=attraction', 'tourism=museum', 'historic=*'],
            'hospitals': ['amenity=hospital', 'amenity=clinic', 'amenity=pharmacy'],
            'banks': ['amenity=bank', 'amenity=atm'],
            'parks': ['leisure=park', 'leisure=garden', 'leisure=playground'],
            'entertainment': ['amenity=theatre', 'amenity=cinema'],
            'sports': ['leisure=sports_centre', 'leisure=stadium'],
            'government': ['amenity=townhall', 'amenity=post_office'],
            'religious': ['amenity=place_of_worship'],
            'utilities': ['amenity=toilets', 'amenity=drinking_water'],
            'business_services': ['office=company', 'amenity=coworking_space'],
            'automotive': ['shop=car_repair', 'amenity=car_wash'],
            'childcare': ['amenity=childcare', 'leisure=playground'],
            'emergency': ['amenity=police', 'amenity=fire_station']
        }

        if not categories:
            return {cat: tag_mapping.get(cat, []) for cat in ['hotels', 'restaurants', 'shops', 'transport', 'attractions', 'parks']}
        return {cat: tag_mapping.get(cat, []) for cat in categories if cat in tag_mapping}

    def _process_osm_result(self, result: overpy.Result, limit: int) -> List[POI]:
        """Process OSM query result from a combined query into POI objects"""
        pois = []

        # Process nodes
        for node in result.nodes:
            if len(pois) >= limit: break
            poi = POI(
                id=f"node_{node.id}",
                name=node.tags.get('name', f"POI {node.id}"),
                lat=float(node.lat),
                lon=float(node.lon),
                tags=node.tags,
                geometry=Point(float(node.lon), float(node.lat)),
                osm_type="node",
                importance_score=self._calculate_importance_score(node.tags)
            )
            pois.append(poi)

        # Process ways and relations (they are similar when using 'out center;')
        combined_geometries = result.ways + result.relations
        for element in combined_geometries:
            if len(pois) >= limit: break
            
            lat, lon = self._get_element_center(element)
            if lat is not None and lon is not None:
                osm_type = "way" if isinstance(element, overpy.Way) else "relation"
                poi = POI(
                    id=f"{osm_type}_{element.id}",
                    name=element.tags.get('name', f"POI {element.id}"),
                    lat=float(lat),
                    lon=float(lon),
                    tags=element.tags,
                    geometry=Point(float(lon), float(lat)),
                    osm_type=osm_type,
                    importance_score=self._calculate_importance_score(element.tags)
                )
                pois.append(poi)

        return pois

    def _get_element_center(self, element: Union[overpy.Way, overpy.Relation]) -> Tuple[Optional[float], Optional[float]]:
        """Get center coordinates of a way or relation."""
        # 'out center;' provides these attributes directly
        if hasattr(element, 'center_lat') and element.center_lat:
            return element.center_lat, element.center_lon
        
        # Fallback for ways if center is not available
        if isinstance(element, overpy.Way) and hasattr(element, 'nodes') and element.nodes:
            lats = [float(n.lat) for n in element.nodes if hasattr(n, 'lat')]
            lons = [float(n.lon) for n in element.nodes if hasattr(n, 'lon')]
            if lats and lons:
                return sum(lats)/len(lats), sum(lons)/len(lons)
                
        return None, None
        
    
    def _calculate_importance_score(self, tags: Dict[str, str]) -> float:
        """Calculate importance score based on OSM tags"""
        score = 0.0

        # Base score for having a name
        if tags.get('name'):
            score += 1.0

        # Additional score for specific amenities/tourism
        importance_tags = {
            'tourism': {'attraction': 3.0, 'museum': 2.5, 'hotel': 2.0, 'viewpoint': 2.0},
            'amenity': {'university': 2.5, 'hospital': 2.0, 'school': 1.5, 'restaurant': 1.0},
            'railway': {'station': 2.0, 'subway_entrance': 1.5},
            'shop': {'mall': 2.0, 'supermarket': 1.0},
            'historic': {'*': 2.0}
        }

        for key, values in importance_tags.items():
            if key in tags:
                tag_value = tags[key]
                if tag_value in values:
                    score += values[tag_value]
                elif '*' in values:
                    score += values['*']

        return score


    def get_search_metrics(self) -> Dict[str, Any]:
        """Get comprehensive search engine metrics"""
        return {
            'total_queries': self.metrics.total_queries,
            'cache_hit_rate': round(self.metrics.cache_hit_rate, 1),
            'cache_hits': self.metrics.cache_hits,
            'cache_misses': self.metrics.cache_misses,
            'api_requests': self.metrics.api_requests,
            'average_response_time': round(self.metrics.average_response_time, 3),
            'error_count': self.metrics.error_count,
            'error_rate': round(self.metrics.error_count / max(self.metrics.total_queries, 1) * 100, 1),
            'cache_enabled': self.cache_enabled
        }

    def clear_cache(self, older_than_hours: int = None):
        """Clear cache entries"""
        if not os.path.exists(self.cache_dir):
            return

        cleared_count = 0
        cutoff_time = datetime.now() - timedelta(hours=older_than_hours) if older_than_hours else None

        for filename in os.listdir(self.cache_dir):
            if filename.endswith('.pkl'):
                file_path = os.path.join(self.cache_dir, filename)

                try:
                    if cutoff_time:
                        # Check file modification time
                        mod_time = datetime.fromtimestamp(os.path.getmtime(file_path))
                        if mod_time > cutoff_time:
                            continue

                    os.remove(file_path)
                    cleared_count += 1

                except Exception as e:
                    logger.warning(f"Failed to remove cache file {filename}: {e}")

        logger.info(f"Cleared {cleared_count} cache entries")

    def find_nearby_pois(self, lat: float, lon: float, radius_km: float = 1.0,
                        categories: List[str] = None, limit: int = 50) -> List[POI]:
        """
        Find POIs near a specific location

        Args:
            lat: Latitude of center point
            lon: Longitude of center point
            radius_km: Search radius in kilometers
            categories: POI categories to search for
            limit: Maximum number of results

        Returns:
            List of nearby POIs sorted by distance
        """
        # Create bounding box around the point
        lat_offset = radius_km / 111.0
        lon_offset = radius_km / (111.0 * abs(math.cos(math.radians(lat))))

        bbox = (
            lat - lat_offset,  # south
            lon - lon_offset,  # west
            lat + lat_offset,  # north
            lon + lon_offset   # east
        )

        # Search for POIs in the area
        pois = self._execute_poi_search(bbox, categories or [], limit * 2)  # Get more for filtering

        # Filter and sort by actual distance
        center_point = Point(lon, lat)
        nearby_pois = []

        for poi in pois:
            distance = geodesic((lat, lon), (poi.lat, poi.lon)).km
            if distance <= radius_km:
                poi.search_relevance = 1.0 / (1.0 + distance)  # Closer = higher relevance
                nearby_pois.append(poi)

        # Sort by distance
        nearby_pois.sort(key=lambda p: geodesic((lat, lon), (p.lat, p.lon)).km)

        return nearby_pois[:limit]

    def calculate_distance_matrix(self, locations: Union[List[POI], List[Tuple[float, float]], List[List[float]]],
                                 profile: str = "car", location_names: Optional[List[str]] = None,
                                 use_cache: bool = True) -> Optional[Dict[str, Any]]:
        """
        Calculate distance matrix using geographic distance calculation.

        Args:
            locations: List of locations in one of these formats:
                      - List of POI objects
                      - List of (longitude, latitude) tuples
                      - List of [longitude, latitude] lists
            profile: Travel profile ('car', 'foot', 'bicycle')
            location_names: Optional names for locations (used for display)
            use_cache: Whether to use caching for results

        Returns:
            Dictionary containing distance matrix data or None if failed
        """
        if not locations:
            logger.warning("No locations provided for distance matrix calculation")
            return None

        if len(locations) < 2:
            logger.warning("Need at least 2 locations for distance matrix")
            return None

        if len(locations) > 100:
            logger.warning("Too many locations (max 100). Truncating to first 100.")
            locations = locations[:100]

        # Convert locations to coordinate format
        coordinates = []
        names = location_names or []

        for i, location in enumerate(locations):
            if isinstance(location, POI):
                # Convert POI to coordinates
                coordinates.append([location.lon, location.lat])
                if not location_names and hasattr(location, 'name'):
                    names.append(location.name)
                elif not names:
                    names.append(f"POI {i+1}")
            elif isinstance(location, (list, tuple)) and len(location) >= 2:
                # Already coordinate format
                coordinates.append([float(location[0]), float(location[1])])
                if not location_names:
                    names.append(f"Location {i+1}")
            else:
                logger.error(f"Invalid location format at index {i}: {location}")
                return None

        # Ensure we have names for all locations
        while len(names) < len(coordinates):
            names.append(f"Location {len(names) + 1}")

        # Generate cache key
        cache_key = self._get_distance_matrix_cache_key(coordinates, profile)

        # Check cache first
        if use_cache and self.cache_enabled:
            cached_result = self._load_from_cache(cache_key)
            if cached_result:
                logger.debug(f"Using cached distance matrix for {profile} profile")
                return cached_result

        # Calculate distance matrix using direct geographic calculation
        try:
            result = self._calculate_geographic_distance_matrix(coordinates, profile, names)

            if result and use_cache and self.cache_enabled:
                self._save_to_cache(cache_key, result)

            return result

        except Exception as e:
            logger.error(f"Failed to calculate distance matrix: {e}")
            return None


    def _get_distance_matrix_cache_key(self, coordinates: List[List[float]], profile: str) -> str:
        """Generate cache key for distance matrix"""
        coords_str = ";".join([f"{coord[0]:.6f},{coord[1]:.6f}" for coord in coordinates])
        key_data = f"distance_matrix_{profile}_{coords_str}"
        return hashlib.sha256(key_data.encode()).hexdigest()

    def _calculate_geographic_distance_matrix(self, coordinates: List[List[float]], profile: str,
                                            location_names: List[str]) -> Optional[Dict[str, Any]]:
        """Calculate distance matrix using geographic distances"""
        # Validate profile
        valid_profiles = ['car', 'foot', 'bicycle']
        if profile not in valid_profiles:
            logger.error(f"Invalid profile '{profile}'. Must be one of: {valid_profiles}")
            return None

        if not coordinates or len(coordinates) < 2:
            return None

        try:
            start_time = time.time()
            num_locations = len(coordinates)

            # Initialize distance and duration matrices
            distances = [[0.0 for _ in range(num_locations)] for _ in range(num_locations)]
            durations = [[0.0 for _ in range(num_locations)] for _ in range(num_locations)]

            # Calculate geographic distances between all pairs
            for i in range(num_locations):
                for j in range(num_locations):
                    if i == j:
                        distances[i][j] = 0.0
                        durations[i][j] = 0.0
                    else:
                        coord1 = coordinates[i]
                        coord2 = coordinates[j]

                        # Calculate geodesic distance in meters
                        geo_distance = geodesic((coord1[1], coord1[0]), (coord2[1], coord2[0])).meters
                        distances[i][j] = geo_distance

                        # Estimate duration based on profile and distance
                        if profile == "foot":
                            estimated_duration = geo_distance / 1.4
                        elif profile == "car":
                            estimated_duration = geo_distance / 8.3
                        elif profile == "bicycle":
                            estimated_duration = geo_distance / 4.2
                        else:
                            estimated_duration = geo_distance / 1.4

                        durations[i][j] = estimated_duration

            request_time = time.time() - start_time

            matrix_data = {
                'success': True,
                'profile': profile,
                'method': 'geographic',
                'locations': coordinates,
                'location_names': location_names,
                'request_time': request_time,
                'timestamp': datetime.now().isoformat(),
                'distances': distances,
                'durations': durations
            }

            return matrix_data

        except Exception as e:
            logger.error(f"Failed to calculate geographic distance matrix: {e}")
            return None


    def calculate_distance_matrix_from_pois(self, pois: List[POI], profile: str = "car") -> Optional[Dict[str, Any]]:
        """
        Convenience method to calculate distance matrix directly from POI objects.

        Args:
            pois: List of POI objects
            profile: Travel profile ('car', 'foot', 'bicycle')

        Returns:
            Distance matrix data or None if failed
        """
        if not pois:
            logger.warning("No POIs provided for distance matrix calculation")
            return None

        # Extract names for better display
        location_names = [poi.name for poi in pois]

        return self.calculate_distance_matrix(pois, profile, location_names)

    def calculate_distance_matrix_from_coordinates(self, coordinates: List[Tuple[float, float]],
                                                 location_names: Optional[List[str]] = None,
                                                 profile: str = "car") -> Optional[Dict[str, Any]]:
        """
        Convenience method to calculate distance matrix from coordinate tuples.

        Args:
            coordinates: List of (longitude, latitude) tuples
            location_names: Optional names for locations
            profile: Travel profile ('car', 'foot', 'bicycle')

        Returns:
            Distance matrix data or None if failed
        """
        return self.calculate_distance_matrix(coordinates, profile, location_names)


# Convenience function for quick searches
def search_osm(query: str, location: str = None, limit: int = 100) -> List[POI]:
    """
    Convenience function for quick OSM searches

    Args:
        query: Search query
        location: Optional location to search in
        limit: Maximum results

    Returns:
        List of POI objects
    """
    engine = OSMSearchEngine()
    # Simplified search logic for the convenience function
    search_query = engine.parse_search_query(f"{query} in {location}" if location else query)
    return engine.search_pois(search_query, limit)


if __name__ == "__main__":
    # Configure basic logging for testing
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    # Quick test
    engine = OSMSearchEngine()
    results = engine.search_pois("hotels in Moscow", limit=5)

    print(f"\nFound {len(results)} results:")
    for poi in results:
        print(f"- {poi.name} (ID: {poi.id}, Importance: {poi.importance_score:.2f})")

    # Test metrics
    print("\nSearch Metrics:")
    print(json.dumps(engine.get_search_metrics(), indent=2))