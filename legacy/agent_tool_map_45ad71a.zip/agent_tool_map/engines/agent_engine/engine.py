import json
import logging
import time
import os
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field

import requests

# Импорт движков
from engines.map_search_engine.engine import OSMSearchEngine, POI
from engines.map_viz_engine.engine import MapEngine

# Импорт конфигурации
from config import (
    CACHE_DIR, CACHE_ENABLED, RESULTS_DIR,
    DEFAULT_MAP_ZOOM, DEFAULT_MAP_TILES
)

logger = logging.getLogger(__name__)


@dataclass
class AgentQuery:
    """Структура для анализа запроса пользователя"""
    raw_query: str
    intent: str = ""
    location: Optional[str] = None
    poi_types: List[str] = field(default_factory=list)
    search_radius: Optional[float] = None
    max_results: int = 50
    visualization_type: str = "markers"
    analysis_type: Optional[str] = None
    filters: Dict[str, Any] = field(default_factory=dict)
    confidence_score: float = 0.0
    parsed_terms: List[str] = field(default_factory=list)


@dataclass
class AgentResult:
    """Структура для результатов работы агента"""
    query: AgentQuery
    pois: List[POI] = field(default_factory=list)
    map_file: Optional[str] = None
    analysis_report: Dict[str, Any] = field(default_factory=dict)
    search_metrics: Dict[str, Any] = field(default_factory=dict)
    processing_time: float = 0.0
    success: bool = False
    error_message: Optional[str] = None


class OllamaClient:
    """Клиент для работы с Ollama API"""

    def __init__(self, base_url: str = "http://localhost:11434", model: str = "gpt-oss:20b"):
        self.base_url = base_url
        self.model = model
        self.timeout = 120
        self.max_retries = 3

    def generate(self, prompt: str, temperature: float = 0.1, max_tokens: int = 2048) -> Optional[str]:
        """Генерация ответа от модели Ollama"""
        payload = {
            "model": self.model,
            "prompt": prompt,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False
        }

        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=self.timeout
            )
            if response.status_code == 200:
                return response.json().get("response", "")
        except Exception as e:
            logger.error(f"Ollama request failed: {e}")
        return None

    def test_connection(self) -> bool:
        """Проверка соединения с Ollama"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=10)
            return response.status_code == 200
        except Exception:
            return False


class MapAgent:
    """
    Интеллектуальный агент для работы с картами

    Основные возможности:
    - Анализ естественных запросов на русском языке
    - Поиск точек интереса через OSM Search Engine
    - Создание интерактивных карт через MapEngine
    - Генерация аналитических отчетов
    """

    def __init__(self,
                 ollama_model: str = "gpt-oss:20b",
                 ollama_url: str = "http://localhost:11434",
                 cache_dir: str = CACHE_DIR,
                 results_dir: str = RESULTS_DIR):
        """Инициализация агента"""
        self.ollama_model = ollama_model
        self.ollama_url = ollama_url
        self.cache_dir = cache_dir
        self.results_dir = results_dir

        # Инициализация компонентов
        self.ollama = OllamaClient(ollama_url, ollama_model)
        self.search_engine = OSMSearchEngine(cache_dir=cache_dir, cache_enabled=CACHE_ENABLED)
        self.map_engine = None

        # Простая статистика
        self.stats = {
            'queries_processed': 0,
            'successful_searches': 0,
            'maps_generated': 0,
            'average_processing_time': 0.0,
            'error_count': 0
        }
        self._query_cache = {}

        # Создание директорий
        os.makedirs(results_dir, exist_ok=True)
        os.makedirs(cache_dir, exist_ok=True)

    def process_query(self, user_query: str) -> AgentResult:
        """Основной метод обработки запроса пользователя"""
        start_time = time.time()
        self.stats['queries_processed'] += 1

        try:
            # Анализ запроса
            query_analysis = self._analyze_query(user_query)
            if not query_analysis:
                return self._create_error_result(user_query, "Не удалось проанализировать запрос")

            # Поиск POI
            pois = self._search_pois(query_analysis)
            if not pois:
                return self._create_error_result(user_query, "Не найдено подходящих точек интереса", query_analysis)

            # Создание карты и анализ
            map_file = self._create_visualization(query_analysis, pois)
            analysis = self._generate_analysis(query_analysis, pois)
            search_metrics = self.search_engine.get_search_metrics()

            # Обновление статистики
            processing_time = time.time() - start_time
            self._update_stats(success=True, has_map=bool(map_file))

            return AgentResult(
                query=query_analysis, pois=pois, map_file=map_file,
                analysis_report=analysis, search_metrics=search_metrics,
                processing_time=processing_time, success=True
            )

        except Exception as e:
            processing_time = time.time() - start_time
            self._update_stats(success=False)
            logger.error(f"Ошибка обработки запроса: {e}")
            return self._create_error_result(user_query, str(e), processing_time=processing_time)

    def _create_error_result(self, user_query: str, error_message: str,
                           query: Optional[AgentQuery] = None,
                           processing_time: float = 0.0) -> AgentResult:
        """Создание результата с ошибкой"""
        return AgentResult(
            query=query or AgentQuery(raw_query=user_query),
            success=False,
            error_message=error_message,
            processing_time=processing_time
        )

    def _update_stats(self, success: bool, has_map: bool = False):
        """Обновление статистики агента"""
        if success:
            self.stats['successful_searches'] += 1
            if has_map:
                self.stats['maps_generated'] += 1
        else:
            self.stats['error_count'] += 1

    def _analyze_query(self, query: str) -> Optional[AgentQuery]:
        """Анализ запроса пользователя с помощью Ollama"""
        # Проверка кеша
        cache_key = f"analysis_{hash(query)}"
        if cache_key in self._query_cache:
            return self._query_cache[cache_key]

        # Простой промпт для анализа
        analysis_prompt = f"""
            Проанализируй запрос и верни JSON:
            ЗАПРОС: "{query}"

            Верни JSON:
            {{
                "intent": "search",
                "location": "Москва",
                "poi_types": ["restaurants"],
                "max_results": 50,
                "visualization_type": "markers",
                "confidence_score": 0.9
            }}
        """

        response = self.ollama.generate(analysis_prompt)
        if not response:
            return None

        try:
            analysis_data = json.loads(response.strip())
            if analysis_data is None:
                return None

            agent_query = AgentQuery(
                raw_query=query,
                intent=analysis_data.get('intent', 'search'),
                location=analysis_data.get('location'),
                poi_types=analysis_data.get('poi_types', []),
                max_results=analysis_data.get('max_results', 50),
                visualization_type=analysis_data.get('visualization_type', 'markers'),
                confidence_score=analysis_data.get('confidence_score', 0.0)
            )

            self._query_cache[cache_key] = agent_query
            return agent_query

        except json.JSONDecodeError:
            return None

    def _search_pois(self, query: AgentQuery) -> List[POI]:
        """Поиск точек интереса на основе анализа запроса"""
        try:
            # Формирование поискового запроса
            search_terms = []
            if query.poi_types:
                search_terms.extend(query.poi_types)
            if query.location:
                search_terms.append(f"в {query.location}")

            search_string = " ".join(search_terms) or query.raw_query

            # Поиск POI
            return self.search_engine.search_pois(search_string, limit=query.max_results)

        except Exception as e:
            logger.error(f"Ошибка поиска POI: {e}")
            return []

    def _create_visualization(self, query: AgentQuery, pois: List[POI]) -> Optional[str]:
        """Создание визуализации на основе типа запроса"""
        if not pois:
            return None

        try:
            self._initialize_map_engine(pois)
            return self._create_marker_visualization(query, pois)
        except Exception as e:
            logger.error(f"Ошибка создания визуализации: {e}")
            return None

    def _initialize_map_engine(self, pois: List[POI]):
        """Инициализация MapEngine если необходимо"""
        if not self.map_engine:
            center_lat = sum(poi.lat for poi in pois) / len(pois)
            center_lon = sum(poi.lon for poi in pois) / len(pois)

            self.map_engine = MapEngine(
                location=[center_lat, center_lon],
                zoom_start=DEFAULT_MAP_ZOOM,
                tiles=DEFAULT_MAP_TILES
            )

    def _create_marker_visualization(self, query: AgentQuery, pois: List[POI]) -> Optional[str]:
        """Создание визуализации с маркерами"""
        try:
            # Простые маркеры для всех POI
            marker_data = [{
                'lat': poi.lat, 'lon': poi.lon, 'name': poi.name,
                'popup': f"{poi.name}\n{poi.category or 'POI'}",
                'icon': 'fa-map-marker', 'color': 'blue'
            } for poi in pois]

            self.map_engine.add_custom_markers(marker_data, f"POI ({len(pois)})", use_clusters=True)
            self.map_engine.add_layer_control()

            return self._save_and_reset_map("map_agent_result")

        except Exception as e:
            logger.error(f"Ошибка создания маркерной визуализации: {e}")
            return None


    def _save_and_reset_map(self, filename_prefix: str) -> str:
        """Сохранение карты и сброс состояния"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        filename = f"{filename_prefix}_{timestamp}.html"
        filepath = os.path.join(self.results_dir, filename)

        result_path = self.map_engine.save_to_html(filepath)
        self._reset_map_engine()

        return result_path

    # Simplified methods for tests
    def _create_heatmap_visualization(self, query: AgentQuery, pois: List[POI]) -> Optional[str]:
        """Simplified heatmap visualization"""
        return self._create_marker_visualization(query, pois)

    def _create_route_visualization(self, query: AgentQuery, pois: List[POI]) -> Optional[str]:
        """Simplified route visualization"""
        return self._create_marker_visualization(query, pois)

    def _create_area_visualization(self, query: AgentQuery, pois: List[POI]) -> Optional[str]:
        """Simplified area visualization"""
        return self._create_marker_visualization(query, pois)

    def _convert_pois_to_building_data(self, pois: List[POI], building_type: str) -> List[Dict]:
        """Convert POIs to building data"""
        return [{
            'lat': poi.lat, 'lon': poi.lon, 'type': building_type, 'name': poi.name,
            'floors': poi.tags.get('building:levels', 1),
            'address': poi.tags.get('addr:full', ''),
            'year_built': poi.tags.get('start_date', '')
        } for poi in pois]

    def _convert_pois_to_emoji_data(self, pois: List[POI], emoji: str) -> List[Dict]:
        """Convert POIs to emoji data"""
        return [{
            'lat': poi.lat, 'lon': poi.lon, 'emoji': emoji, 'name': poi.name,
            'popup': f"{poi.name}\n{poi.category or 'POI'}\n{poi.tags.get('description', '')}"
        } for poi in pois]

    def _generate_legend_items(self, poi_groups: Dict[str, List[POI]]) -> Dict[str, str]:
        """Generate legend items"""
        return {
            f"{poi_type.title()}": 'blue'
            for poi_type in poi_groups.keys()
        }

    def _generate_recommendations(self, query: AgentQuery, pois: List[POI]) -> List[str]:
        """Generate recommendations"""
        return ["Рекомендуется посетить наиболее высокооцененные точки интереса"]

    def _generate_insights(self, query: AgentQuery, pois: List[POI]) -> List[str]:
        """Generate insights"""
        return [f"Найдены разнообразные точки интереса в указанном районе"]

    def _update_average_time(self, processing_time: float):
        """Update average processing time"""
        total_queries = self.stats['queries_processed']
        current_avg = self.stats['average_processing_time']
        self.stats['average_processing_time'] = (
            (current_avg * total_queries) + processing_time
        ) / (total_queries + 1)
        self.stats['queries_processed'] = total_queries + 1


    def _generate_analysis(self, query: AgentQuery, pois: List[POI]) -> Dict[str, Any]:
        """Генерация аналитического отчета"""
        try:
            # Простой анализ
            categories = {}
            for poi in pois:
                cat = poi.category or 'general'
                categories[cat] = categories.get(cat, 0) + 1

            return {
                'summary': {
                    'total_pois': len(pois),
                    'query_type': query.intent,
                    'location': query.location,
                    'poi_types': list(set([poi.category for poi in pois if poi.category]))
                },
                'statistics': {'categories': categories},
                'recommendations': [f"Найдено {len(pois)} точек интереса в районе {query.location or 'указанном'}"],
                'insights': [f"Основные категории: {', '.join(list(categories.keys())[:3])}"]
            }

        except Exception as e:
            logger.error(f"Ошибка генерации анализа: {e}")
            return {'error': str(e)}

    def _reset_map_engine(self):
        """Сброс состояния карты для следующего использования"""
        self.map_engine = None

    def get_agent_stats(self) -> Dict[str, Any]:
        """Получение статистики работы агента"""
        return {
            'queries_processed': self.stats['queries_processed'],
            'successful_searches': self.stats['successful_searches'],
            'maps_generated': self.stats['maps_generated'],
            'error_count': self.stats['error_count'],
            'success_rate': (
                self.stats['successful_searches'] / self.stats['queries_processed'] * 100
                if self.stats['queries_processed'] > 0 else 0
            ),
            'average_processing_time': round(self.stats['average_processing_time'], 2),
            'ollama_connected': self.ollama.test_connection(),
            'cache_enabled': self.search_engine.cache_enabled
        }

    def clear_cache(self):
        """Очистка кешей"""
        self.search_engine.clear_cache()
        self._query_cache.clear()

    def test_connection(self) -> Dict[str, Any]:
        """Тестирование всех подключений"""
        results = {
            'ollama': self.ollama.test_connection(),
            'search_engine': True,
            'map_engine': True,
            'cache_dir': os.path.exists(self.cache_dir),
            'results_dir': os.path.exists(self.results_dir)
        }
        results['overall_status'] = all(results.values())
        return results
