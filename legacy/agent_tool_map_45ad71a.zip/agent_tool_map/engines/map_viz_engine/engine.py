import folium
import pandas as pd
import logging
from typing import List, Dict, Tuple, Any, Optional, Union
from folium.plugins import MarkerCluster, HeatMap
from folium import Icon, Circle, CircleMarker, Polygon, PolyLine
import os

logger = logging.getLogger(__name__)


class MapEngine:
    """
    Simplified map visualization engine supporting multiple visualization types.
    """

    def __init__(self, location: List[float] = [55.7522, 37.6156], zoom_start: int = 10,
                 tiles: str = 'OpenStreetMap', width: str = '100%', height: str = '100%'):
        """
        Initialize the map engine.

        :param location: list, initial map center coordinates [latitude, longitude]
        :param zoom_start: int, initial zoom level
        :param tiles: str, tile provider ('OpenStreetMap', 'Stamen Terrain', etc.)
        :param width: str, map width (CSS units)
        :param height: str, map height (CSS units)
        """
        self.map = folium.Map(location=location, zoom_start=zoom_start, tiles=tiles, width=width, height=height)
        self.layers = []
        self.layer_groups = {}
        logger.info(f"MapEngine initialized at {location} with {tiles} tiles")

    def _create_layer_group(self, layer_name: str) -> folium.FeatureGroup:
        """Create and return a new layer group"""
        return folium.FeatureGroup(name=layer_name)

    def _add_layer_to_map(self, layer_group: folium.FeatureGroup, layer_name: str) -> None:
        """Add layer group to map and track it"""
        layer_group.add_to(self.map)
        self.layers.append(layer_name)

    def add_marker_cluster(self, points_data: List[Union[List, Tuple]],
                          layer_name: str = "Points Cluster",
                          use_popups: bool = True,
                          icon_color: str = 'blue',
                          icon_prefix: str = 'fa',
                          icon_type: str = 'circle') -> None:
        """
        Add clustered markers to the map.

        :param points_data: List of point data. Format: [[lat, lon, popup], ...] or [[lat, lon], ...]
        :param layer_name: Name for the layer group
        :param use_popups: Whether to show popups on markers
        :param icon_color: Color of marker icons
        :param icon_prefix: Icon prefix (fa for FontAwesome, glyphicon for Bootstrap)
        :param icon_type: Type of icon to use
        """
        logger.info(f"Adding marker cluster with {len(points_data)} points")

        layer_group = self._create_layer_group(layer_name)
        marker_cluster = MarkerCluster().add_to(layer_group)

        for point in points_data:
            if len(point) >= 2:
                lat, lon = point[0], point[1]
                popup_text = str(point[2]) if len(point) > 2 and use_popups else None
                icon = Icon(color=icon_color, prefix=icon_prefix, icon=icon_type)
                marker = folium.Marker(location=[lat, lon], popup=popup_text, icon=icon)
                marker.add_to(marker_cluster)

        self._add_layer_to_map(layer_group, layer_name)

    def add_building_markers(self, building_data: List[Dict[str, Any]],
                           layer_name: str = "Buildings",
                           use_clusters: bool = True,
                           icon_color: str = 'blue') -> None:
        """
        Add building markers with custom building-specific icons.

        :param building_data: List of building data dictionaries
        :param layer_name: Name for the layer
        :param use_clusters: Whether to cluster markers
        :param icon_color: Base color for building icons
        """
        logger.info(f"Adding {len(building_data)} building markers")

        layer_group = self._create_layer_group(layer_name)
        target = MarkerCluster().add_to(layer_group) if use_clusters else layer_group

        for building in building_data:
            lat = building.get('lat', building.get('latitude', 0))
            lon = building.get('lon', building.get('longitude', 0))
            building_type = building.get('type', 'building')
            name = building.get('name', f'Building at {lat:.4f}, {lon:.4f}')

            icon = self._create_building_icon(building_type, icon_color)
            marker = folium.Marker(
                location=[lat, lon],
                popup=self._create_building_popup(building),
                icon=icon
            )
            marker.add_to(target)

        self._add_layer_to_map(layer_group, layer_name)

    def add_emoji_markers(self, emoji_data: List[Dict[str, Any]],
                         layer_name: str = "Emoji Markers",
                         use_clusters: bool = False) -> None:
        """
        Add emoji markers to the map.

        :param emoji_data: List of emoji marker data dictionaries
        :param layer_name: Name for the layer
        :param use_clusters: Whether to cluster markers
        """
        logger.info(f"Adding {len(emoji_data)} emoji markers")

        layer_group = self._create_layer_group(layer_name)
        target = MarkerCluster().add_to(layer_group) if use_clusters else layer_group

        for marker_info in emoji_data:
            lat = marker_info.get('lat', marker_info.get('latitude', 0))
            lon = marker_info.get('lon', marker_info.get('longitude', 0))
            emoji = marker_info.get('emoji', '📍')
            popup_text = marker_info.get('popup', marker_info.get('name', ''))

            emoji_icon = self._create_emoji_icon(emoji)
            marker = folium.Marker(location=[lat, lon], popup=popup_text, icon=emoji_icon)
            marker.add_to(target)

        self._add_layer_to_map(layer_group, layer_name)

    def add_custom_markers(self, marker_data: List[Dict[str, Any]],
                          layer_name: str = "Custom Markers",
                          use_clusters: bool = True,
                          default_icon: str = 'circle') -> None:
        """
        Add custom markers with flexible icon options.

        :param marker_data: List of marker data dictionaries
        :param layer_name: Name for the layer
        :param use_clusters: Whether to cluster markers
        :param default_icon: Default icon type
        """
        logger.info(f"Adding {len(marker_data)} custom markers")

        layer_group = self._create_layer_group(layer_name)
        target = MarkerCluster().add_to(layer_group) if use_clusters else layer_group

        for marker_info in marker_data:
            lat = marker_info.get('lat', marker_info.get('latitude', 0))
            lon = marker_info.get('lon', marker_info.get('longitude', 0))
            icon_type = marker_info.get('icon', default_icon)
            icon_color = marker_info.get('color', 'blue')
            popup_text = marker_info.get('popup', marker_info.get('name', ''))

            icon = self._create_custom_icon(icon_type, icon_color)
            marker = folium.Marker(location=[lat, lon], popup=popup_text, icon=icon)
            marker.add_to(target)

        self._add_layer_to_map(layer_group, layer_name)

    def add_custom_legend(self, legend_items: Dict[str, str],
                         title: str = "Legend",
                         position: str = 'bottomright',
                         background_color: str = 'rgba(255, 255, 255, 0.95)',
                         border_color: str = '#2C3E50',
                         border_width: int = 2) -> None:
        """
        Add a custom legend to the map with enhanced styling.

        :param legend_items: Dictionary mapping labels to colors/icons
        :param title: Legend title
        :param position: Legend position (topleft, topright, bottomleft, bottomright)
        :param background_color: Background color (supports transparency)
        :param border_color: Border color
        :param border_width: Border width in pixels
        """
        logger.info(f"Adding custom legend with {len(legend_items)} items")

        # Position mapping
        position_styles = {
            'topleft': 'top: 10px; left: 10px;',
            'topright': 'top: 10px; right: 10px;',
            'bottomleft': 'bottom: 10px; left: 10px;',
            'bottomright': 'bottom: 10px; right: 10px;'
        }

        position_style = position_styles.get(position, position_styles['bottomright'])
        # fixed
        legend_html = f"""
        <div style="position: fixed;
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                    {position_style}
                    background-color: {background_color};
                    border: {border_width}px solid {border_color};
                    border-radius: 8px;
                    padding: 12px;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.15);
                    z-index: 1000;
                    max-width: 800px;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    font-size: 13px;
                    backdrop-filter: blur(5px);">
            <h4 style="margin: 0 0 12px 0;
                       color: {border_color};
                       font-size: 16px;
                       font-weight: 600;
                       text-align: center;
                       border-bottom: 1px solid #eee;
                       padding-bottom: 8px;">{title}</h4>
        """

        for label, color_or_icon in legend_items.items():
            if color_or_icon.startswith('#') or color_or_icon in ['red', 'blue', 'green', 'yellow', 'orange', 'purple', 'black', 'white', 'gray']:
                # Color-based legend item
                legend_html += f"""
                <div style="display: flex; align-items: center; margin-bottom: 8px;">
                    <div style="width: 18px; height: 18px; background-color: {color_or_icon};
                               border: 2px solid white; border-radius: 50%;
                               margin-right: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.2);"></div>
                    <span style="color: #333; font-weight: 500;">{label}</span>
                </div>
                """
            else:
                # Emoji or icon-based legend item
                legend_html += f"""
                <div style="display: flex; align-items: center; margin-bottom: 8px;">
                    <div style="width: 24px; height: 24px; display: flex; align-items: center;
                               justify-content: center; background: white; border-radius: 50%;
                               margin-right: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.2);
                               border: 1px solid #ddd;">
                        <span style="font-size: 16px; line-height: 1;">{color_or_icon}</span>
                    </div>
                    <span style="color: #333; font-weight: 500;">{label}</span>
                </div>
                """

        legend_html += "</div>"

        # Add the legend to the map
        self.map.get_root().html.add_child(folium.Element(legend_html))

    def _create_building_icon(self, building_type: str, base_color: str) -> folium.Icon:
        """Create building-specific icons."""
        icon_map = {
            'house': 'home',
            'apartment': 'building',
            'office': 'briefcase',
            'hotel': 'bed',
            'restaurant': 'cutlery',
            'shop': 'shopping-cart',
            'school': 'graduation-cap',
            'hospital': 'plus-square',
            'bank': 'university',
            'park': 'tree',
        }

        icon_name = icon_map.get(building_type, 'building')
        return Icon(color=base_color, prefix='fa', icon=icon_name, icon_color='white')

    def _create_emoji_icon(self, emoji: str) -> folium.Icon:
        """Create emoji-based custom icon with white border for better visibility."""
        # Create a custom div icon with emoji and white border
        emoji_icon = folium.DivIcon(
            html=f'''
            <div style="
                font-size: 28px;
                text-align: center;
                line-height: 28px;
                background: white;
                border: 2px solid white;
                border-radius: 50%;
                width: 32px;
                height: 32px;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            ">{emoji}</div>
            ''',
            icon_size=(32, 32),
            icon_anchor=(16, 16)
        )
        return emoji_icon

    def _create_custom_icon(self, icon_type: str, color: str) -> folium.Icon:
        """Create custom icons with enhanced styling options."""
        if icon_type in ['circle', 'square', 'star', 'triangle']:
            # Use Bootstrap icons for shapes with enhanced styling
            return Icon(
                color=color,
                prefix='glyphicon',
                icon='asterisk',
                icon_color='white'
            )
        elif icon_type.startswith('fa-'):
            # FontAwesome icon with enhanced styling
            return Icon(
                color=color,
                prefix='fa',
                icon=icon_type[3:],
                icon_color='white',
                angle=0,
                reset=False
            )
        else:
            # Default to FontAwesome icon with enhanced styling
            return Icon(
                color=color,
                prefix='fa',
                icon=icon_type,
                icon_color='white',
                angle=0,
                reset=False
            )

    def _create_building_popup(self, building: Dict[str, Any]) -> str:
        """Create detailed popup for building markers."""
        fields = [
            ('type', '🏢 Type: {}'),
            ('address', '📍 Address: {}'),
            ('floors', '🏗️ Floors: {}'),
            ('year_built', '📅 Year Built: {}')
        ]

        popup_content = [f"<h4 style='margin: 0 0 8px 0; color: #2C3E50; font-size: 14px;'>{building.get('name', 'Building')}</h4>"]

        for field, template in fields:
            if field in building:
                popup_content.append(f"<p style='margin: 4px 0; color: #7F8C8D; font-size: 12px;'>{template.format(building[field])}</p>")

        return f"""
        <div style='font-family: Arial, sans-serif; max-width: 500px; background: rgba(255,255,255,0.95);
                    padding: 12px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.15);'>
            {''.join(popup_content)}</div>"""

    def add_polyline(self, line_points: List[List[float]],
                    layer_name: str = "Line",
                    color: str = 'blue',
                    weight: int = 3,
                    opacity: float = 0.8,
                    popup_text: Optional[str] = None,
                    dash_array: Optional[str] = None) -> None:
        """
        Add a polyline to the map.

        :param line_points: List of [lat, lon] coordinates
        :param layer_name: Name for the layer
        :param color: Line color
        :param weight: Line weight in pixels
        :param opacity: Line opacity (0-1)
        :param popup_text: Popup text for the line
        :param dash_array: Dash pattern (e.g., '5, 5' for dashed line)
        """
        logger.info(f"Adding polyline with {len(line_points)} points")

        layer_group = self._create_layer_group(layer_name)
        PolyLine(locations=line_points, color=color, weight=weight, opacity=opacity,
                popup=popup_text, dash_array=dash_array).add_to(layer_group)
        self._add_layer_to_map(layer_group, layer_name)

    def add_heatmap(self, points_data: List[List[float]],
                   layer_name: str = "Heatmap",
                   radius: int = 15,
                   blur: int = 10,
                   max_zoom: int = 1,
                   min_opacity: float = 0.5,
                   max_opacity: float = 0.8) -> None:
        """
        Add a heatmap layer to the map.

        :param points_data: List of [lat, lon] or [lat, lon, intensity] points
        :param layer_name: Name for the layer
        :param radius: Heat point radius
        :param blur: Heat point blur
        :param max_zoom: Maximum zoom level for heatmap
        :param min_opacity: Minimum opacity
        :param max_opacity: Maximum opacity
        """
        logger.info(f"Adding heatmap with {len(points_data)} points")

        layer_group = self._create_layer_group(layer_name)
        HeatMap(data=points_data, radius=radius, blur=blur, max_zoom=max_zoom,
                min_opacity=min_opacity, max_opacity=max_opacity).add_to(layer_group)
        self._add_layer_to_map(layer_group, layer_name)

    def add_choropleth(self, geo_data_path: str,
                      data: pd.DataFrame,
                      columns: List[str],
                      key_on: str,
                      layer_name: str = "Choropleth",
                      fill_color: str = 'YlGn',
                      fill_opacity: float = 0.7,
                      line_opacity: float = 0.2,
                      line_color: str = 'black',
                      line_weight: int = 1,
                      legend_name: str = 'Value') -> None:
        """
        Add choropleth polygons to the map.

        :param geo_data_path: Path to GeoJSON file
        :param data: DataFrame with data for coloring
        :param columns: [key_column, value_column]
        :param key_on: Key path in GeoJSON for data binding
        :param layer_name: Name for the layer
        :param fill_color: Color scheme name
        :param fill_opacity: Fill opacity
        :param line_opacity: Line opacity
        :param line_color: Line color
        :param line_weight: Line weight
        :param legend_name: Legend title
        """
        logger.info(f"Adding choropleth layer from {geo_data_path}")

        folium.Choropleth(
            geo_data=geo_data_path,
            name=layer_name,
            data=data,
            columns=columns,
            key_on=key_on,
            fill_color=fill_color,
            fill_opacity=fill_opacity,
            line_opacity=line_opacity,
            line_color=line_color,
            line_weight=line_weight,
            legend_name=legend_name
        ).add_to(self.map)

        self.layers.append(layer_name)

    def add_polygon(self, coords: List[List[float]],
                   layer_name: str = "Polygon",
                   color: str = 'blue',
                   fill_color: str = 'blue',
                   fill_opacity: float = 0.2,
                   weight: int = 2,
                   popup_text: Optional[str] = None) -> None:
        """
        Add a polygon to the map.

        :param coords: List of [lat, lon] coordinates
        :param layer_name: Name for the layer
        :param color: Border color
        :param fill_color: Fill color
        :param fill_opacity: Fill opacity
        :param weight: Border weight
        :param popup_text: Popup text
        """
        logger.info(f"Adding polygon with {len(coords)} vertices")

        layer_group = self._create_layer_group(layer_name)
        Polygon(locations=coords, color=color, fill_color=fill_color,
                fill_opacity=fill_opacity, weight=weight, popup=popup_text).add_to(layer_group)
        self._add_layer_to_map(layer_group, layer_name)

    def add_circle_marker(self, center: List[float],
                         layer_name: str = "Circle Marker",
                         radius: int = 10,
                         color: str = 'blue',
                         fill_color: str = 'blue',
                         fill_opacity: float = 0.6,
                         popup_text: Optional[str] = None) -> None:
        """
        Add a circle marker to the map.

        :param center: [lat, lon] center point
        :param layer_name: Name for the layer
        :param radius: Circle radius in pixels
        :param color: Border color
        :param fill_color: Fill color
        :param fill_opacity: Fill opacity
        :param popup_text: Popup text
        """
        logger.info(f"Adding circle marker at {center}")

        layer_group = self._create_layer_group(layer_name)
        CircleMarker(location=center, radius=radius, color=color, fill_color=fill_color,
                    fill_opacity=fill_opacity, popup=popup_text).add_to(layer_group)
        self._add_layer_to_map(layer_group, layer_name)

    def add_circle(self, center: List[float],
                  layer_name: str = "Circle",
                  radius: int = 100,
                  color: str = 'red',
                  fill_color: str = 'red',
                  fill_opacity: float = 0.2,
                  weight: int = 2,
                  popup_text: Optional[str] = None) -> None:
        """
        Add a circle to the map.

        :param center: [lat, lon] center point
        :param layer_name: Name for the layer
        :param radius: Circle radius in meters
        :param color: Border color
        :param fill_color: Fill color
        :param fill_opacity: Fill opacity
        :param weight: Border weight
        :param popup_text: Popup text
        """
        logger.info(f"Adding circle at {center} with radius {radius}m")

        layer_group = self._create_layer_group(layer_name)
        Circle(location=center, radius=radius, color=color, fill_color=fill_color,
               fill_opacity=fill_opacity, weight=weight, popup=popup_text).add_to(layer_group)
        self._add_layer_to_map(layer_group, layer_name)

    def add_layer_control(self) -> None:
        """
        Add layer control widget to the map.
        Should be called after adding all layers.
        """
        folium.LayerControl().add_to(self.map)
        logger.info("Added layer control to map")

    def save_to_html(self, filename: str = 'map.html', auto_open: bool = False) -> str:
        """
        Save the created map to an HTML file.

        :param filename: Output filename
        :param auto_open: Whether to automatically open the file in browser
        :return: Full path to saved file
        """
        # Ensure .html extension
        if not filename.endswith('.html'):
            filename += '.html'

        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(filename) if os.path.dirname(filename) else '.', exist_ok=True)

        self.map.save(filename)
        logger.info(f"Map successfully saved to: {filename}")

        if auto_open:
            import webbrowser
            webbrowser.open(filename)

        return os.path.abspath(filename)

if __name__ == '__main__':
    print("Creating simplified map visualization demo...")
    engine = MapEngine(location=[55.7522, 37.6156], zoom_start=10)
    
    # Simple demo
    points_data = [
        [55.75, 37.61, "Point 1"],
        [55.76, 37.62, "Point 2"],
        [55.74, 37.63, "Point 3"]
    ]
    engine.add_marker_cluster(points_data, "Demo Points", icon_color='green')
    engine.add_layer_control()
    
    demo_file = engine.save_to_html('simplified_demo_map.html')
    print(f"Demo map created and saved to: {demo_file}")