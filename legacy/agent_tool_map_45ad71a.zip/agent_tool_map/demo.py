import os
import json
import logging
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field

from engines.map_search_engine.engine import OSMSearchEngine, POI
from engines.map_viz_engine.engine import MapEngine
from engines.agent_engine.engine import OllamaClient
from config import (
    CACHE_DIR, CACHE_ENABLED, RESULTS_DIR,
    PRIMARY_MODEL, MODEL_TEMPERATURE, MODEL_MAX_TOKENS
)


@dataclass
class SearchParams:
    """Parameters extracted from user query via LLM"""
    location: Optional[str] = None
    primary_poi_type: Optional[str] = None
    secondary_poi_type: Optional[str] = None
    search_radius_km: float = 5.0


@dataclass
class SearchResult:
    """Results from POI search"""
    location: str
    primary_pois: List[POI] = field(default_factory=list)
    secondary_pois: List[POI] = field(default_factory=list)
    poi_scores: Dict[str, float] = field(default_factory=dict)
    best_primary_pois: List[Tuple[POI, float]] = field(default_factory=list)
    search_params: Optional[SearchParams] = None
    map_file: Optional[str] = None
    processing_time: float = 0.0
    success: bool = False
    error_message: Optional[str] = None


class POISearchDemo:
    """Simplified POI search demo with LLM query analysis and map visualization"""

    def __init__(self, cache_dir: str = CACHE_DIR, results_dir: str = RESULTS_DIR):
        self.cache_dir = cache_dir
        self.results_dir = results_dir

        self.search_engine = OSMSearchEngine(cache_dir=cache_dir, cache_enabled=CACHE_ENABLED)
        self.map_engine = MapEngine()
        self.ollama_client = OllamaClient(base_url="http://localhost:11434", model=PRIMARY_MODEL)

        self.poi_styles = {
            'hotels': {'color': 'blue', 'icon': 'fa-bed', 'emoji': '🏨'},
            'schools': {'color': 'green', 'icon': 'fa-graduation-cap', 'emoji': '🎓'},
            'restaurants': {'color': 'orange', 'icon': 'fa-utensils', 'emoji': '🍽️'},
            'shops': {'color': 'purple', 'icon': 'fa-shopping-bag', 'emoji': '🛍️'},
            'transport': {'color': 'red', 'icon': 'fa-subway', 'emoji': '🚇'},
            'attractions': {'color': 'darkgreen', 'icon': 'fa-camera', 'emoji': '🏛️'},
            'hospitals': {'color': 'darkred', 'icon': 'fa-plus', 'emoji': '🏥'},
            'parks': {'color': 'lightgreen', 'icon': 'fa-tree', 'emoji': '🌳'},
            'banks': {'color': 'gray', 'icon': 'fa-university', 'emoji': '🏦'},
            'default': {'color': 'black', 'icon': 'fa-map-marker', 'emoji': '📍'}
        }

        os.makedirs(results_dir, exist_ok=True)

        if not self.ollama_client.test_connection():
            raise Exception("LLM not available")
        logging.info("POI search demo initialized")

    def analyze_query(self, query: str) -> Optional[SearchParams]:
        """Analyze user query using LLM to extract search parameters."""
        prompt = f"""
        Analyze this query and return ONLY valid JSON: "{query}"

        Return JSON with:
        - location: city name
        - primary_poi_type: main POI type (hotels, schools, restaurants, shops, hospitals, banks, parks, attractions, business_services)
        - secondary_poi_type: secondary POI type (same options, can be transport for stations)
        - search_radius_km: search radius in km (default 5.0)

        Examples:
        - "Hotels near metro in Moscow" → {{"location": "Moscow", "primary_poi_type": "hotels", "secondary_poi_type": "transport"}}
        - "Schools in Kazan near shops" → {{"location": "Kazan", "primary_poi_type": "schools", "secondary_poi_type": "shops"}}
        """

        try:
            response = self.ollama_client.generate(
                prompt=prompt,
                temperature=MODEL_TEMPERATURE,
                max_tokens=MODEL_MAX_TOKENS
            )
            if not response:
                return None

            # Extract JSON from response
            start = response.find('{')
            end = response.rfind('}') + 1
            if start != -1 and end > start:
                json_str = response[start:end]
                data = json.loads(json_str)

                return SearchParams(
                    location=data.get('location'),
                    primary_poi_type=data.get('primary_poi_type'),
                    secondary_poi_type=data.get('secondary_poi_type'),
                    search_radius_km=data.get('search_radius_km', 5.0)
                )
        except Exception as e:
            logging.error(f"Query analysis failed: {e}")

        return None

    def get_city_coords(self, city_name: str) -> Optional[Tuple[float, float]]:
        """Get city coordinates from OSM."""
        country = "Россия" if any(city in city_name for city in [
            'Москва', 'Санкт-Петербург', 'Екатеринбург', 'Казань', 'Новосибирск',
            'Нижний Новгород', 'Самара', 'Омск', 'Челябинск', 'Уфа', 'Красноярск',
            'Воронеж', 'Пермь', 'Волгоград', 'Краснодар'
        ]) else None

        coords = self.search_engine.get_city_coordinates(city_name, country)
        if coords:
            lat, lon = coords
            # Check if coordinates are within Russia bounds
            if 41.0 <= lat <= 82.0 and 19.0 <= lon <= 180.0:
                return coords
        return None

    def search_pois(self, location: str, search_params: SearchParams) -> Tuple[List[POI], List[POI]]:
        """Search for POIs based on parameters."""
        city_coords = self.get_city_coords(location)
        if not city_coords:
            return [], []

        lat, lon = city_coords
        radius = search_params.search_radius_km

        categories = []
        if search_params.primary_poi_type:
            categories.append(search_params.primary_poi_type)
        if search_params.secondary_poi_type:
            categories.append(search_params.secondary_poi_type)

        if not categories:
            categories = ['hotels', 'restaurants', 'shops']

        all_pois = self.search_engine.find_nearby_pois(
            lat=lat, lon=lon, radius_km=radius, categories=categories, limit=100
        )

        primary_pois = []
        secondary_pois = []

        for poi in all_pois:
            # Check bounds
            if not (41.0 <= poi.lat <= 82.0 and 19.0 <= poi.lon <= 180.0):
                continue

            poi_type = self._classify_poi_type(poi)

            if poi_type == search_params.primary_poi_type and len(primary_pois) < 30:
                primary_pois.append(poi)
            elif poi_type == search_params.secondary_poi_type and len(secondary_pois) < 30:
                secondary_pois.append(poi)

        logging.info(f"Found {len(primary_pois)} {search_params.primary_poi_type} and {len(secondary_pois)} {search_params.secondary_poi_type}")
        return primary_pois, secondary_pois

    def _classify_poi_type(self, poi: POI) -> Optional[str]:
        """Classify POI by type based on OSM tags and categories."""
        if poi.category:
            cat = poi.category.lower()
            if 'hotel' in cat or 'accommodation' in cat:
                return 'hotels'
            elif 'school' in cat or 'education' in cat:
                return 'schools'
            elif 'restaurant' in cat or 'food' in cat or 'cafe' in cat:
                return 'restaurants'
            elif 'shop' in cat or 'store' in cat:
                return 'shops'
            elif 'transport' in cat or 'station' in cat:
                return 'transport'
            elif 'attraction' in cat or 'tourism' in cat or 'museum' in cat:
                return 'attractions'

        if poi.tags:
            amenity = poi.tags.get('amenity', '').lower()
            tourism = poi.tags.get('tourism', '').lower()
            shop = poi.tags.get('shop', '').lower()
            leisure = poi.tags.get('leisure', '').lower()

            if amenity in ['restaurant', 'cafe', 'bar', 'fast_food']:
                return 'restaurants'
            elif amenity in ['school', 'university', 'college']:
                return 'schools'
            elif amenity in ['hospital', 'clinic', 'pharmacy']:
                return 'hospitals'
            elif amenity in ['bank', 'atm']:
                return 'banks'
            elif amenity in ['parking', 'fuel']:
                return 'transport'
            elif tourism in ['hotel', 'hostel', 'motel']:
                return 'hotels'
            elif tourism in ['museum', 'attraction', 'viewpoint']:
                return 'attractions'
            elif leisure in ['park', 'garden']:
                return 'parks'
            elif shop:
                return 'shops'

        return None

    def calculate_distance_matrix(self, primary_pois: List[POI], secondary_pois: List[POI]) -> Optional[Dict]:
        """Calculate distance matrix between primary and secondary POIs."""
        if not primary_pois or not secondary_pois:
            return None

        # Limit POIs for performance
        limited_primary = primary_pois[:20]
        limited_secondary = secondary_pois[:20]
        
        all_locations = limited_primary + limited_secondary

        try:
            matrix_data = self.search_engine.calculate_distance_matrix(
                locations=all_locations,
                profile="foot",
                location_names=[loc.name for loc in all_locations],
                use_cache=True
            )

            if matrix_data and matrix_data.get('success'):
                matrix_data['limited_primary'] = limited_primary
                matrix_data['limited_secondary'] = limited_secondary
                return matrix_data
        except Exception as e:
            logging.error(f"Distance matrix calculation failed: {e}")

        return None

    def score_pois_by_proximity(self, primary_pois: List[POI], secondary_pois: List[POI], 
                              matrix_data: Dict) -> Dict[str, float]:
        """Score primary POIs based on proximity to secondary POIs."""
        poi_scores = {}
        
        if not matrix_data or not matrix_data.get('distances'):
            return poi_scores

        distances = matrix_data['distances']
        limited_primary = matrix_data.get('limited_primary', primary_pois)
        limited_secondary = matrix_data.get('limited_secondary', secondary_pois)

        for i, primary_poi in enumerate(limited_primary):
            poi_id = primary_poi.id
            total_score = 0.0
            proximity_count = 0

            for j, secondary_poi in enumerate(limited_secondary):
                secondary_idx = len(limited_primary) + j
                
                if i < len(distances) and secondary_idx < len(distances[i]):
                    distance = distances[i][secondary_idx]
                    if distance and distance <= 2000:  # 2km threshold
                        # Score based on inverse distance
                        score = 1.0 / (1.0 + distance / 1000.0)
                        total_score += score
                        proximity_count += 1

            # Normalize score
            if len(limited_secondary) > 0:
                final_score = total_score / len(limited_secondary)
                poi_scores[poi_id] = final_score

        return poi_scores

    def find_best_pois(self, primary_pois: List[POI], poi_scores: Dict[str, float], 
                      top_n: int = 5) -> List[Tuple[POI, float]]:
        """Find best primary POIs based on scores."""
        scored_pois = []
        for poi in primary_pois:
            score = poi_scores.get(poi.id, 0.0)
            scored_pois.append((poi, score))

        scored_pois.sort(key=lambda x: x[1], reverse=True)
        return scored_pois[:top_n]

    def create_map(self, result: SearchResult) -> Optional[str]:
        """Create interactive map showing POIs."""
        if not result.primary_pois and not result.secondary_pois:
            return None

        try:
            city_coords = self.get_city_coords(result.location)
            if not city_coords:
                return None

            self.map_engine = MapEngine(
                location=city_coords,
                zoom_start=13,
                tiles='CartoDB positron'
            )

            # Add search area
            self.map_engine.add_circle(
                center=city_coords,
                layer_name="Search Area",
                radius=int(result.search_params.search_radius_km * 1000),
                color='blue',
                fill_opacity=0.1
            )

            # Add primary POIs with scoring visualization
            if result.primary_pois:
                primary_type = result.search_params.primary_poi_type
                style = self.poi_styles.get(primary_type, self.poi_styles['default'])
                
                # Create custom markers with scores
                custom_markers = []
                for poi in result.primary_pois[:20]:
                    score = result.poi_scores.get(poi.id, 0.0)
                    score_percent = int(score * 100)
                    
                    # Color based on score
                    if score >= 0.7:
                        color = 'green'
                        quality = 'Excellent'
                    elif score >= 0.4:
                        color = 'orange'
                        quality = 'Good'
                    else:
                        color = 'red'
                        quality = 'Basic'
                    
                    popup = f"""
                    <div style='font-family: Arial, sans-serif; max-width: 300px;'>
                        <h4 style='margin: 0 0 8px 0; color: #2C3E50;'>{style['emoji']} {poi.name}</h4>
                        <p style='margin: 4px 0; color: #7F8C8D;'><strong>Type:</strong> {primary_type.title()}</p>
                        <p style='margin: 4px 0; color: #27AE60; font-weight: bold;'>
                            Score: {score:.2f} ({score_percent}%) - {quality}
                        </p>
                        <p style='margin: 4px 0; color: #34495E; font-size: 12px;'>
                            📍 {poi.lat:.4f}, {poi.lon:.4f}
                        </p>
                    </div>
                    """
                    
                    custom_markers.append({
                        'lat': poi.lat,
                        'lon': poi.lon,
                        'icon': style['icon'],
                        'color': color,
                        'name': poi.name,
                        'popup': popup
                    })

                self.map_engine.add_custom_markers(
                    custom_markers,
                    layer_name=f"{style['emoji']} {primary_type.title()} (Ranked)",
                    use_clusters=True
                )

            # Add secondary POIs
            if result.secondary_pois:
                secondary_type = result.search_params.secondary_poi_type
                style = self.poi_styles.get(secondary_type, self.poi_styles['default'])
                secondary_data = []
                for poi in result.secondary_pois[:20]:  # Limit to 20
                    popup = f"<b>{poi.name}</b><br>{secondary_type.title()}"
                    secondary_data.append([poi.lat, poi.lon, popup])

                self.map_engine.add_marker_cluster(
                    secondary_data,
                    layer_name=f"{style['emoji']} {secondary_type.title()}",
                    icon_color=style['color'],
                    icon_type=style['icon'].replace('fa-', '')
                )

            # Add best POIs with special markers
            if result.best_primary_pois:
                best_poi_data = []
                for i, (poi, score) in enumerate(result.best_primary_pois[:3], 1):
                    rank_emojis = {1: '🥇', 2: '🥈', 3: '🥉'}
                    emoji = rank_emojis.get(i, '🏆')
                    
                    popup = f"""
                    <div style='font-family: Arial, sans-serif; text-align: center; padding: 10px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border-radius: 8px;'>
                        <span style='font-size: 24px;'>{emoji}</span>
                        <h3 style='margin: 5px 0; color: white;'>#{i} BEST {result.search_params.primary_poi_type.upper()}</h3>
                        <h4 style='margin: 0 0 10px 0; color: #FFE066;'>{poi.name}</h4>
                        <p style='margin: 0; font-size: 16px; font-weight: bold;'>
                            ⭐ Score: {score:.2f} ({int(score*100)}%)
                        </p>
                    </div>
                    """
                    
                    best_poi_data.append({
                        'lat': poi.lat,
                        'lon': poi.lon,
                        'popup': popup,
                        'emoji': emoji
                    })

                self.map_engine.add_emoji_markers(
                    best_poi_data,
                    layer_name=f"🥇 Top 3 {result.search_params.primary_poi_type.title()}s",
                    use_clusters=False
                )

            self.map_engine.add_layer_control()

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"poi_search_{result.location.lower().replace(' ', '_')}_{timestamp}.html"
            filepath = os.path.join(self.results_dir, filename)

            saved_file = self.map_engine.save_to_html(filepath, auto_open=False)
            return saved_file

        except Exception as e:
            logging.error(f"Map creation failed: {e}")
            return None

    def run_search(self, user_query: str) -> SearchResult:
        """Run POI search with LLM analysis."""
        start_time = time.time()
        result = SearchResult(location="")

        logging.info(f"Starting POI search for: '{user_query}'")

        try:
            search_params = self.analyze_query(user_query)
            if not search_params or not search_params.location:
                result.error_message = f"Could not analyze query: '{user_query}'"
                return result

            result.location = search_params.location
            result.search_params = search_params

            primary_pois, secondary_pois = self.search_pois(search_params.location, search_params)
            result.primary_pois = primary_pois
            result.secondary_pois = secondary_pois

            if not primary_pois:
                result.error_message = f"No {search_params.primary_poi_type} found in {search_params.location}"
                return result

            # Calculate distance matrix and score POIs if secondary POIs exist
            if secondary_pois:
                logging.info("Calculating distance matrix and scoring POIs...")
                matrix_data = self.calculate_distance_matrix(primary_pois, secondary_pois)
                
                if matrix_data:
                    result.poi_scores = self.score_pois_by_proximity(primary_pois, secondary_pois, matrix_data)
                    result.best_primary_pois = self.find_best_pois(primary_pois, result.poi_scores, top_n=5)
                    logging.info(f"Scored {len(result.poi_scores)} POIs, found {len(result.best_primary_pois)} best")
                else:
                    # Fallback: assign equal scores
                    result.poi_scores = {poi.id: 1.0 for poi in primary_pois}
                    result.best_primary_pois = [(poi, 1.0) for poi in primary_pois[:5]]
            else:
                # No secondary POIs, assign equal scores
                result.poi_scores = {poi.id: 1.0 for poi in primary_pois}
                result.best_primary_pois = [(poi, 1.0) for poi in primary_pois[:5]]

            result.map_file = self.create_map(result)
            result.success = True
            result.processing_time = time.time() - start_time

            logging.info(f"Search completed: {len(primary_pois)} {search_params.primary_poi_type}, {len(secondary_pois)} {search_params.secondary_poi_type}")

        except Exception as e:
            result.error_message = str(e)
            result.processing_time = time.time() - start_time
            logging.error(f"Search failed: {e}")

        return result

    def print_summary(self, result: SearchResult):
        """Print search results summary."""
        print(f"\n{'='*50}")
        print(f"POI SEARCH RESULTS - {result.location.upper()}")
        print(f"{'='*50}")

        print(f"Success: {result.success}")
        print(f"Primary POIs: {len(result.primary_pois)} {result.search_params.primary_poi_type if result.search_params else 'POIs'}")
        print(f"Secondary POIs: {len(result.secondary_pois)} {result.search_params.secondary_poi_type if result.search_params else 'POIs'}")
        print(f"Processing time: {result.processing_time:.2f} seconds")

        if result.best_primary_pois:
            print(f"\n🏆 TOP {result.search_params.primary_poi_type.upper()}S:")
            for i, (poi, score) in enumerate(result.best_primary_pois, 1):
                print(f"   {i}. {poi.name} (Score: {score:.2f})")

        if result.error_message:
            print(f"Error: {result.error_message}")

        if result.map_file:
            print(f"Map saved: {result.map_file}")

        print(f"{'='*50}")


def main():
    """Main demo function."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('poi_search_demo.log'),
            logging.StreamHandler()
        ]
    )

    demo = POISearchDemo()

    queries = [
        "Проведи бизнес-анализ: найди оптимальные места для открытия кафе в центре Москвы в радиусе 2 км, рядом с парками и остановками транспорта",
        "Для семьи с детьми: найди в Екатеринбурге детские сады, школы и парки в радиусе 1.5 км от центра города, с анализом безопасности района и доступности транспорта",
        "Инвестиционный анализ: оцени потенциал для открытия магазина электроники в Казани - найди места рядом с метро и торговыми центрами в радиусе 3 км",
    ]

    for i, query in enumerate(queries, 1):
        print(f"\n{'='*60}")
        print(f"Query {i}/{len(queries)}: {query}")

        result = demo.run_search(query)
        demo.print_summary(result)


if __name__ == "__main__":
    main()
