import pytest
import os
import shutil

from engines.agent_engine.engine import (
    MapAgent, AgentQuery, AgentResult, OllamaClient,
    AgentQuery, AgentResult
)

# Import dependencies
from engines.map_search_engine.engine import POI
from engines.map_viz_engine.engine import MapEngine

# Import configuration
from config import (
    CACHE_DIR, RESULTS_DIR, DEFAULT_MAP_ZOOM, DEFAULT_MAP_TILES
)

# Test configuration
TEST_CACHE_DIR = "/tmp/test_agent_cache"
TEST_RESULTS_DIR = "/tmp/test_agent_results"
TEST_TIMEOUT = 30  # seconds for API calls
TEST_CITY = "Moscow"  # Use a well-known city for testing
TEST_COORDINATES = (55.7558, 37.6176)  # Moscow coordinates


class TestDataClasses:
    """Test all dataclass structures and their methods"""

    def test_agent_query_creation_and_methods(self):
        """Test AgentQuery dataclass creation and methods"""
        query = AgentQuery(
            raw_query="Find restaurants in Moscow",
            intent="search",
            location="Moscow",
            poi_types=["restaurants"],
            search_radius=5.0,
            max_results=20,
            visualization_type="markers",
            analysis_type="business",
            filters={"cuisine": "italian"},
            confidence_score=0.85,
            parsed_terms=["restaurants", "moscow"]
        )

        assert query.raw_query == "Find restaurants in Moscow"
        assert query.intent == "search"
        assert query.location == "Moscow"
        assert "restaurants" in query.poi_types
        assert query.search_radius == 5.0
        assert query.max_results == 20
        assert query.visualization_type == "markers"
        assert query.analysis_type == "business"
        assert query.filters["cuisine"] == "italian"
        assert query.confidence_score == 0.85
        assert "restaurants" in query.parsed_terms

    def test_agent_result_creation_and_methods(self):
        """Test AgentResult dataclass creation and methods"""
        # Create a sample POI
        poi = POI(
            id="test_poi_123",
            name="Test Restaurant",
            lat=55.7558,
            lon=37.6176,
            tags={"amenity": "restaurant", "cuisine": "italian"},
            geometry=None,
            category="restaurants"
        )

        query = AgentQuery(raw_query="test query")
        result = AgentResult(
            query=query,
            pois=[poi],
            map_file="/path/to/map.html",
            analysis_report={"summary": "Test analysis"},
            search_metrics={"total_queries": 1},
            processing_time=2.5,
            success=True,
            error_message=None
        )

        assert result.query == query
        assert len(result.pois) == 1
        assert result.pois[0].name == "Test Restaurant"
        assert result.map_file == "/path/to/map.html"
        assert result.analysis_report["summary"] == "Test analysis"
        assert result.processing_time == 2.5
        assert result.success == True
        assert result.error_message is None

    def test_agent_query_defaults(self):
        """Test AgentQuery default values"""
        query = AgentQuery(raw_query="simple query")

        assert query.intent == ""
        assert query.location is None
        assert query.poi_types == []
        assert query.search_radius is None
        assert query.max_results == 50
        assert query.visualization_type == "markers"
        assert query.analysis_type is None
        assert query.filters == {}
        assert query.confidence_score == 0.0
        assert query.parsed_terms == []

    def test_agent_result_defaults(self):
        """Test AgentResult default values"""
        query = AgentQuery(raw_query="test")
        result = AgentResult(query=query)

        assert result.pois == []
        assert result.map_file is None
        assert result.analysis_report == {}
        assert result.search_metrics == {}
        assert result.processing_time == 0.0
        assert result.success == False
        assert result.error_message is None


class TestOllamaClient:
    """Test OllamaClient functionality"""

    def test_ollama_client_creation(self):
        """Test OllamaClient initialization"""
        client = OllamaClient(
            base_url="http://localhost:11434",
            model="gpt-oss:20b"
        )

        assert client.base_url == "http://localhost:11434"
        assert client.model == "gpt-oss:20b"
        assert client.timeout == 120
        assert client.max_retries == 3

    @pytest.mark.skipif(not os.environ.get('TEST_OLLAMA'), reason="Ollama not available for testing")
    def test_ollama_connection_test(self):
        """Test Ollama connection (only if Ollama is running)"""
        client = OllamaClient()
        is_connected = client.test_connection()

        # This will be True if Ollama is running, False otherwise
        assert isinstance(is_connected, bool)

    @pytest.mark.skipif(not os.environ.get('TEST_OLLAMA'), reason="Ollama not available for testing")
    def test_ollama_generate_response(self):
        """Test Ollama response generation (only if Ollama is running)"""
        client = OllamaClient()

        prompt = "Say 'Hello, World!' and nothing else."
        response = client.generate(prompt, temperature=0.1, max_tokens=50)

        # If Ollama is running, we should get a response
        if response:
            assert isinstance(response, str)
            assert len(response.strip()) > 0
        else:
            # If no response, that's also acceptable (Ollama not running)
            assert response is None

    def test_ollama_client_with_invalid_url(self):
        """Test OllamaClient with invalid URL"""
        client = OllamaClient(base_url="http://invalid.url:9999")

        response = client.generate("test prompt", max_tokens=10)
        assert response is None

        is_connected = client.test_connection()
        assert is_connected == False


class TestMapAgentInitialization:
    """Test MapAgent initialization and core functionality"""

    @pytest.fixture
    def temp_dirs(self):
        """Create temporary directories for testing"""
        if os.path.exists(TEST_CACHE_DIR):
            shutil.rmtree(TEST_CACHE_DIR)
        if os.path.exists(TEST_RESULTS_DIR):
            shutil.rmtree(TEST_RESULTS_DIR)

        os.makedirs(TEST_CACHE_DIR)
        os.makedirs(TEST_RESULTS_DIR)

        yield TEST_CACHE_DIR, TEST_RESULTS_DIR

        # Cleanup after test
        if os.path.exists(TEST_CACHE_DIR):
            shutil.rmtree(TEST_CACHE_DIR)
        if os.path.exists(TEST_RESULTS_DIR):
            shutil.rmtree(TEST_RESULTS_DIR)

    def test_map_agent_creation(self, temp_dirs):
        """Test MapAgent initialization"""
        cache_dir, results_dir = temp_dirs

        agent = MapAgent(
            ollama_model="gpt-oss:20b",
            ollama_url="http://localhost:11434",
            cache_dir=cache_dir,
            results_dir=results_dir
        )

        assert agent.ollama_model == "gpt-oss:20b"
        assert agent.ollama_url == "http://localhost:11434"
        assert agent.cache_dir == cache_dir
        assert agent.results_dir == results_dir

        # Check that components are initialized
        assert agent.ollama is not None
        assert agent.search_engine is not None
        assert agent.map_engine is None  # Should be None initially
        assert isinstance(agent.stats, dict)
        assert isinstance(agent._query_cache, dict)

        # Check that directories were created
        assert os.path.exists(cache_dir)
        assert os.path.exists(results_dir)

    def test_map_agent_default_initialization(self, temp_dirs):
        """Test MapAgent with default parameters"""
        cache_dir, results_dir = temp_dirs

        agent = MapAgent()

        assert agent.ollama_model == "gpt-oss:20b"  # Default from MapAgent constructor
        assert agent.ollama_url == "http://localhost:11434"
        assert agent.cache_dir == CACHE_DIR
        assert agent.results_dir == RESULTS_DIR

    def test_map_agent_stats_initialization(self, temp_dirs):
        """Test that MapAgent stats are properly initialized"""
        cache_dir, results_dir = temp_dirs

        agent = MapAgent(cache_dir=cache_dir, results_dir=results_dir)

        required_stats = [
            'queries_processed', 'successful_searches', 'maps_generated',
            'average_processing_time', 'error_count'
        ]

        for stat in required_stats:
            assert stat in agent.stats
            assert isinstance(agent.stats[stat], (int, float))


class TestQueryAnalysis:
    """Test query analysis functionality"""

    @pytest.fixture
    def agent(self):
        """Create MapAgent instance for testing"""
        return MapAgent()  # Disable cache for testing

    @pytest.mark.skipif(not os.environ.get('TEST_OLLAMA'), reason="Ollama not available for testing")
    def test_query_analysis_basic(self, agent):
        """Test basic query analysis with Ollama"""
        query_text = "Find restaurants in Moscow"

        result = agent._analyze_query(query_text)

        if result:  # Only test if Ollama is working
            assert isinstance(result, AgentQuery)
            assert result.raw_query == query_text
            assert isinstance(result.intent, str)
            assert isinstance(result.confidence_score, float)
            assert 0.0 <= result.confidence_score <= 1.0
        else:
            assert result is None

    @pytest.mark.skipif(not os.environ.get('TEST_OLLAMA'), reason="Ollama not available for testing")
    def test_query_analysis_with_cache(self, agent):
        """Test query analysis with caching"""
        query_text = "Find hotels in Paris"

        # First analysis
        result1 = agent._analyze_query(query_text)

        # Second analysis (should use cache)
        result2 = agent._analyze_query(query_text)

        if result1 and result2:  # Only test if Ollama is working
            assert result1.raw_query == result2.raw_query
            assert result1.intent == result2.intent
            assert result1.location == result2.location
            # Should be the same cached result
            assert result1 is result2

    def test_query_analysis_without_ollama(self, agent):
        """Test query analysis when Ollama is not available"""
        # Mock Ollama to return None
        original_generate = agent.ollama.generate
        agent.ollama.generate = lambda *args, **kwargs: None

        try:
            result = agent._analyze_query("test query")
            assert result is None
        finally:
            agent.ollama.generate = original_generate

    def test_query_analysis_json_parsing_error(self, agent):
        """Test query analysis with malformed JSON response"""
        # Mock Ollama to return invalid JSON
        original_generate = agent.ollama.generate
        agent.ollama.generate = lambda *args, **kwargs: "This is not JSON"

        try:
            result = agent._analyze_query("test query")
            assert result is None
        finally:
            agent.ollama.generate = original_generate


class TestPOISearch:
    """Test POI search functionality"""

    @pytest.fixture
    def agent(self):
        """Create MapAgent instance for testing"""
        return MapAgent()

    def test_poi_search_basic(self, agent):
        """Test basic POI search"""
        query = AgentQuery(
            raw_query="restaurants in Moscow",
            intent="search",
            location="Moscow",
            poi_types=["restaurants"],
            max_results=5
        )

        pois = agent._search_pois(query)

        assert isinstance(pois, list)
        assert len(pois) <= 5

        if pois:  # Only test if we got results
            for poi in pois:
                assert isinstance(poi, POI)
                assert poi.name
                assert isinstance(poi.lat, float)
                assert isinstance(poi.lon, float)

    def test_poi_search_without_location(self, agent):
        """Test POI search without explicit location"""
        query = AgentQuery(
            raw_query="hotels",
            intent="search",
            poi_types=["hotels"],
            max_results=3
        )

        pois = agent._search_pois(query)

        assert isinstance(pois, list)
        # Should still work, using raw query

    def test_poi_search_with_radius(self, agent):
        """Test POI search with radius filtering"""
        query = AgentQuery(
            raw_query="shops near Moscow center",
            intent="search",
            location="Moscow",
            poi_types=["shops"],
            search_radius=2.0,  # 2km radius
            max_results=10
        )

        pois = agent._search_pois(query)

        assert isinstance(pois, list)
        assert len(pois) <= 10

    def test_poi_search_empty_types(self, agent):
        """Test POI search with empty POI types"""
        query = AgentQuery(
            raw_query="points of interest in Moscow",
            intent="search",
            location="Moscow",
            poi_types=[],
            max_results=3
        )

        pois = agent._search_pois(query)

        assert isinstance(pois, list)
        # Should handle gracefully

    def test_poi_search_error_handling(self, agent):
        """Test POI search error handling"""
        # Test with invalid query that might cause errors
        query = AgentQuery(
            raw_query="",
            intent="search",
            location=None,
            poi_types=[],
            max_results=1
        )

        pois = agent._search_pois(query)

        # Should return empty list, not crash
        assert isinstance(pois, list)


class TestVisualization:
    """Test visualization creation functionality"""

    @pytest.fixture
    def agent(self):
        """Create MapAgent instance for testing"""
        agent = MapAgent()
        # Initialize map engine for testing
        agent.map_engine = MapEngine(
            location=[55.7558, 37.6176],
            zoom_start=DEFAULT_MAP_ZOOM,
            tiles=DEFAULT_MAP_TILES
        )
        return agent

    @pytest.fixture
    def sample_pois(self):
        """Create sample POIs for testing"""
        return [
            POI(
                id="poi1",
                name="Restaurant 1",
                lat=55.7558,
                lon=37.6176,
                tags={"amenity": "restaurant"},
                geometry=None,
                category="restaurants"
            ),
            POI(
                id="poi2",
                name="Hotel 1",
                lat=55.7560,
                lon=37.6180,
                tags={"tourism": "hotel"},
                geometry=None,
                category="hotels"
            ),
            POI(
                id="poi3",
                name="School 1",
                lat=55.7570,
                lon=37.6190,
                tags={"amenity": "school"},
                geometry=None,
                category="schools"
            )
        ]

    def test_visualization_marker_type(self, agent, sample_pois):
        """Test marker visualization creation"""
        query = AgentQuery(
            raw_query="test query",
            visualization_type="markers"
        )

        result_path = agent._create_marker_visualization(query, sample_pois)

        if result_path:  # Only test if creation succeeded
            assert isinstance(result_path, str)
            assert result_path.endswith('.html')
            assert os.path.exists(result_path)

            # Clean up
            if os.path.exists(result_path):
                os.remove(result_path)

    def test_visualization_heatmap_type(self, agent, sample_pois):
        """Test heatmap visualization creation"""
        query = AgentQuery(
            raw_query="test query",
            visualization_type="heatmap"
        )

        result_path = agent._create_heatmap_visualization(query, sample_pois)

        if result_path:  # Only test if creation succeeded
            assert isinstance(result_path, str)
            assert result_path.endswith('.html')
            assert os.path.exists(result_path)

            # Clean up
            if os.path.exists(result_path):
                os.remove(result_path)

    def test_visualization_route_type(self, agent, sample_pois):
        """Test route visualization creation"""
        query = AgentQuery(
            raw_query="test query",
            visualization_type="routes"
        )

        result_path = agent._create_route_visualization(query, sample_pois)

        if result_path:  # Only test if creation succeeded
            assert isinstance(result_path, str)
            assert result_path.endswith('.html')
            assert os.path.exists(result_path)

            # Clean up
            if os.path.exists(result_path):
                os.remove(result_path)

    def test_visualization_area_type(self, agent, sample_pois):
        """Test area visualization creation"""
        query = AgentQuery(
            raw_query="test query",
            visualization_type="areas"
        )

        # Add more POIs to create a valid area
        more_pois = sample_pois + [
            POI(id="poi4", name="POI 4", lat=55.7580, lon=37.6200,
                tags={}, geometry=None, category="general"),
            POI(id="poi5", name="POI 5", lat=55.7590, lon=37.6210,
                tags={}, geometry=None, category="general"),
            POI(id="poi6", name="POI 6", lat=55.7600, lon=37.6220,
                tags={}, geometry=None, category="general")
        ]

        result_path = agent._create_area_visualization(query, more_pois)

        if result_path:  # Only test if creation succeeded
            assert isinstance(result_path, str)
            assert result_path.endswith('.html')
            assert os.path.exists(result_path)

            # Clean up
            if os.path.exists(result_path):
                os.remove(result_path)

    def test_visualization_empty_pois(self, agent):
        """Test visualization with empty POI list"""
        query = AgentQuery(raw_query="test query")

        result_path = agent._create_visualization(query, [])

        assert result_path is None

    def test_convert_pois_to_building_data(self, agent, sample_pois):
        """Test POI to building data conversion"""
        building_data = agent._convert_pois_to_building_data(sample_pois, "hotel")

        assert isinstance(building_data, list)
        assert len(building_data) == len(sample_pois)

        for data in building_data:
            assert "lat" in data
            assert "lon" in data
            assert "type" in data
            assert "name" in data
            assert "floors" in data
            assert "address" in data

    def test_convert_pois_to_emoji_data(self, agent, sample_pois):
        """Test POI to emoji data conversion"""
        emoji_data = agent._convert_pois_to_emoji_data(sample_pois, "🍽️")

        assert isinstance(emoji_data, list)
        assert len(emoji_data) == len(sample_pois)

        for data in emoji_data:
            assert "lat" in data
            assert "lon" in data
            assert "emoji" in data
            assert "name" in data
            assert "popup" in data

    def test_generate_legend_items(self, agent, sample_pois):
        """Test legend generation"""
        poi_groups = {
            "restaurants": sample_pois[:1],
            "hotels": sample_pois[1:2],
            "schools": sample_pois[2:]
        }

        legend_items = agent._generate_legend_items(poi_groups)

        assert isinstance(legend_items, dict)
        # Should have entries for each POI type
        for poi_type in poi_groups.keys():
            # Check for title case version (e.g., "restaurants" -> "Restaurants")
            expected_key_part = poi_type.title()
            assert any(expected_key_part in key for key in legend_items.keys())


class TestAnalysisGeneration:
    """Test analysis generation functionality"""

    @pytest.fixture
    def agent(self):
        """Create MapAgent instance for testing"""
        return MapAgent()

    @pytest.fixture
    def sample_pois(self):
        """Create sample POIs for testing"""
        return [
            POI(
                id=f"poi{i}",
                name=f"POI {i}",
                lat=55.7558 + i * 0.001,
                lon=37.6176 + i * 0.001,
                tags={"amenity": "restaurant" if i % 2 == 0 else "hotel"},
                geometry=None,
                category="restaurants" if i % 2 == 0 else "hotels",
                importance_score=0.5 + i * 0.1
            )
            for i in range(5)
        ]

    def test_generate_analysis_basic(self, agent, sample_pois):
        """Test basic analysis generation"""
        query = AgentQuery(
            raw_query="Find restaurants in Moscow",
            intent="search",
            location="Moscow"
        )

        analysis = agent._generate_analysis(query, sample_pois)

        assert isinstance(analysis, dict)
        assert "summary" in analysis
        assert "statistics" in analysis
        assert "recommendations" in analysis
        assert "insights" in analysis

        # Check summary
        assert "total_pois" in analysis["summary"]
        assert analysis["summary"]["total_pois"] == len(sample_pois)
        assert analysis["summary"]["query_type"] == query.intent
        assert analysis["summary"]["location"] == query.location

    def test_generate_analysis_empty_pois(self, agent):
        """Test analysis generation with empty POI list"""
        query = AgentQuery(raw_query="test query")

        analysis = agent._generate_analysis(query, [])

        assert isinstance(analysis, dict)
        assert "summary" in analysis
        assert analysis["summary"]["total_pois"] == 0

    @pytest.mark.skipif(not os.environ.get('TEST_OLLAMA'), reason="Ollama not available for testing")
    def test_generate_recommendations(self, agent, sample_pois):
        """Test recommendations generation"""
        query = AgentQuery(raw_query="Find restaurants in Moscow")

        recommendations = agent._generate_recommendations(query, sample_pois)

        assert isinstance(recommendations, list)
        if recommendations:  # Only test if Ollama worked
            for rec in recommendations:
                assert isinstance(rec, str)
                assert len(rec.strip()) > 0

    @pytest.mark.skipif(not os.environ.get('TEST_OLLAMA'), reason="Ollama not available for testing")
    def test_generate_insights(self, agent, sample_pois):
        """Test insights generation"""
        query = AgentQuery(raw_query="Find restaurants in Moscow")

        insights = agent._generate_insights(query, sample_pois)

        assert isinstance(insights, list)
        if insights:  # Only test if Ollama worked
            for insight in insights:
                assert isinstance(insight, str)
                assert len(insight.strip()) > 0

    def test_generate_recommendations_without_ollama(self, agent, sample_pois):
        """Test recommendations generation when Ollama is not available"""
        # Mock Ollama to return None
        original_generate = agent.ollama.generate
        agent.ollama.generate = lambda *args, **kwargs: None

        try:
            query = AgentQuery(raw_query="test query")
            recommendations = agent._generate_recommendations(query, sample_pois)

            # Should return default recommendations
            assert isinstance(recommendations, list)
            assert len(recommendations) > 0
            assert "Рекомендуется" in recommendations[0]
        finally:
            agent.ollama.generate = original_generate

    def test_generate_insights_without_ollama(self, agent, sample_pois):
        """Test insights generation when Ollama is not available"""
        # Mock Ollama to return None
        original_generate = agent.ollama.generate
        agent.ollama.generate = lambda *args, **kwargs: None

        try:
            query = AgentQuery(raw_query="test query")
            insights = agent._generate_insights(query, sample_pois)

            # Should return default insights
            assert isinstance(insights, list)
            assert len(insights) > 0
            assert "Найдены" in insights[0]
        finally:
            agent.ollama.generate = original_generate


class TestStatisticsAndCaching:
    """Test statistics and caching functionality"""

    @pytest.fixture
    def temp_dirs(self):
        """Create temporary directories for testing"""
        if os.path.exists(TEST_CACHE_DIR):
            shutil.rmtree(TEST_CACHE_DIR)
        if os.path.exists(TEST_RESULTS_DIR):
            shutil.rmtree(TEST_RESULTS_DIR)

        os.makedirs(TEST_CACHE_DIR)
        os.makedirs(TEST_RESULTS_DIR)

        yield TEST_CACHE_DIR, TEST_RESULTS_DIR

        # Cleanup after test
        if os.path.exists(TEST_CACHE_DIR):
            shutil.rmtree(TEST_CACHE_DIR)
        if os.path.exists(TEST_RESULTS_DIR):
            shutil.rmtree(TEST_RESULTS_DIR)

    def test_get_agent_stats(self, temp_dirs):
        """Test getting agent statistics"""
        cache_dir, results_dir = temp_dirs

        agent = MapAgent(cache_dir=cache_dir, results_dir=results_dir)

        stats = agent.get_agent_stats()

        assert isinstance(stats, dict)

        required_keys = [
            'queries_processed', 'successful_searches', 'maps_generated',
            'error_count', 'success_rate', 'average_processing_time',
            'ollama_connected', 'cache_enabled'
        ]

        for key in required_keys:
            assert key in stats

        assert isinstance(stats['success_rate'], (int, float))
        assert 0.0 <= stats['success_rate'] <= 100.0
        assert isinstance(stats['average_processing_time'], float)

    def test_clear_cache(self, temp_dirs):
        """Test cache clearing functionality"""
        cache_dir, results_dir = temp_dirs

        agent = MapAgent(cache_dir=cache_dir, results_dir=results_dir)

        # Add some items to query cache
        agent._query_cache["test_key_1"] = AgentQuery(raw_query="test1")
        agent._query_cache["test_key_2"] = AgentQuery(raw_query="test2")

        assert len(agent._query_cache) == 2

        # Clear cache
        agent.clear_cache()

        assert len(agent._query_cache) == 0

    def test_update_average_time(self, temp_dirs):
        """Test average processing time calculation"""
        cache_dir, results_dir = temp_dirs

        agent = MapAgent(cache_dir=cache_dir, results_dir=results_dir)

        # Initial state
        assert agent.stats['queries_processed'] == 0
        assert agent.stats['average_processing_time'] == 0.0

        # Update with first processing time
        agent._update_average_time(2.5)
        assert agent.stats['queries_processed'] == 1
        assert agent.stats['average_processing_time'] == 2.5

        # Update with second processing time
        agent._update_average_time(3.5)
        assert agent.stats['queries_processed'] == 2
        expected_avg = (2.5 + 3.5) / 2  # 3.0
        assert abs(agent.stats['average_processing_time'] - expected_avg) < 0.01

    def test_reset_map_engine(self, temp_dirs):
        """Test map engine reset functionality"""
        cache_dir, results_dir = temp_dirs

        agent = MapAgent(cache_dir=cache_dir, results_dir=results_dir)

        # Initially should be None
        assert agent.map_engine is None

        # Create a map engine
        agent.map_engine = MapEngine()

        assert agent.map_engine is not None

        # Reset
        agent._reset_map_engine()

        assert agent.map_engine is None


class TestErrorHandling:
    """Test error handling and edge cases"""

    @pytest.fixture
    def agent(self):
        """Create MapAgent instance for testing"""
        return MapAgent()

    def test_process_query_with_empty_input(self, agent):
        """Test processing empty query"""
        result = agent.process_query("")

        assert isinstance(result, AgentResult)
        assert result.success == False
        assert result.error_message is not None

    def test_process_query_with_invalid_query(self, agent):
        """Test processing invalid query"""
        # Mock analyze_query to return None
        original_analyze = agent._analyze_query
        agent._analyze_query = lambda x: None

        try:
            result = agent.process_query("invalid query")

            assert isinstance(result, AgentResult)
            assert result.success == False
            assert "Не удалось проанализировать запрос" in result.error_message
        finally:
            agent._analyze_query = original_analyze

    def test_process_query_with_no_pois_found(self, agent):
        """Test processing when no POIs are found"""
        # Mock search to return empty list
        original_search = agent._search_pois
        agent._search_pois = lambda x: []

        # Mock analyze to return valid query
        original_analyze = agent._analyze_query
        agent._analyze_query = lambda x: AgentQuery(raw_query=x, intent="search")

        try:
            result = agent.process_query("query with no results")

            assert isinstance(result, AgentResult)
            assert result.success == False
            assert "Не найдено подходящих точек интереса" in result.error_message
        finally:
            agent._search_pois = original_search
            agent._analyze_query = original_analyze

    def test_process_query_with_visualization_error(self, agent):
        """Test processing when visualization creation fails"""
        # Mock methods to simulate successful analysis and search
        original_analyze = agent._analyze_query
        agent._analyze_query = lambda x: AgentQuery(raw_query=x, intent="search")

        original_search = agent._search_pois
        pois = [POI(id="test", name="Test POI", lat=55.7558, lon=37.6176,
                   tags={}, geometry=None, category="test")]
        agent._search_pois = lambda x: pois

        # Mock visualization to fail
        original_viz = agent._create_visualization
        agent._create_visualization = lambda x, y: None

        try:
            result = agent.process_query("test query")

            # Should still succeed even if visualization fails
            assert isinstance(result, AgentResult)
            assert result.success == True
            assert result.pois == pois
            assert result.map_file is None  # Visualization failed
        finally:
            agent._analyze_query = original_analyze
            agent._search_pois = original_search
            agent._create_visualization = original_viz

    def test_test_connection_method(self, agent):
        """Test the test_connection method"""
        results = agent.test_connection()

        assert isinstance(results, dict)

        required_keys = [
            'ollama', 'search_engine', 'map_engine',
            'cache_dir', 'results_dir', 'overall_status'
        ]

        for key in required_keys:
            assert key in results

        # Values should be boolean
        for key in ['ollama', 'search_engine', 'map_engine', 'overall_status']:
            assert isinstance(results[key], bool)

        # Directory existence should be boolean
        assert isinstance(results['cache_dir'], bool)
        assert isinstance(results['results_dir'], bool)


class TestProcessQueryIntegration:
    """Integration tests for the main process_query method"""

    @pytest.fixture
    def agent(self):
        """Create MapAgent instance for testing"""
        return MapAgent()

    def test_process_query_basic_flow(self, agent):
        """Test the basic flow of process_query"""
        # Use a simple query that should work
        query = "restaurants in Moscow"

        result = agent.process_query(query)

        assert isinstance(result, AgentResult)
        assert isinstance(result.processing_time, float)
        assert result.processing_time >= 0

        # Check that stats were updated
        assert agent.stats['queries_processed'] >= 1

    def test_process_query_statistics_update(self, agent):
        """Test that statistics are properly updated after processing"""
        initial_queries = agent.stats['queries_processed']
        initial_errors = agent.stats['error_count']

        # Process a query (may succeed or fail)
        result = agent.process_query("test query")

        # Statistics should be updated
        assert agent.stats['queries_processed'] > initial_queries

        if result.success:
            assert agent.stats['successful_searches'] >= 1
        else:
            assert agent.stats['error_count'] >= initial_errors


def run_specific_test():
    """Run a specific test to verify functionality"""
    print("Running specific functionality test...")

    # Test basic agent creation and functionality
    agent = MapAgent()

    print("Testing MapAgent creation...")
    print(f"Agent created with model: {agent.ollama_model}")
    print(f"Cache enabled: {agent.search_engine.cache_enabled}")

    print("Testing basic query processing...")
    result = agent.process_query("Find restaurants in Moscow")

    print(f"Query processed in {result.processing_time:.2f} seconds")
    print(f"Success: {result.success}")
    print(f"POIs found: {len(result.pois)}")

    if result.pois:
        print("Sample POIs:")
        for poi in result.pois[:3]:  # Show first 3
            print(f"- {poi.name} ({poi.category}) at {poi.lat:.4f}, {poi.lon:.4f}")

    if result.map_file:
        print(f"Map created: {result.map_file}")
    else:
        print("No map created (likely due to visualization setup)")

    if result.analysis_report:
        print("Analysis summary:")
        summary = result.analysis_report.get('summary', {})
        print(f"- Total POIs: {summary.get('total_pois', 0)}")
        print(f"- Query type: {summary.get('query_type', 'unknown')}")

    print("Testing agent stats...")
    stats = agent.get_agent_stats()
    print(f"Queries processed: {stats['queries_processed']}")
    print(f"Success rate: {stats['success_rate']:.1f}%")
    print(f"Ollama connected: {stats['ollama_connected']}")

    print("Testing connection...")
    connection_results = agent.test_connection()
    print(f"Overall status: {connection_results['overall_status']}")
    for component, status in connection_results.items():
        if component != 'overall_status':
            print(f"- {component}: {status}")

    print("All basic functionality tests completed!")


if __name__ == "__main__":
    # Run the specific test first
    run_specific_test()

    print("\n" + "="*50)
    print("Running pytest...")
    print("="*50)

    # Then run pytest
    pytest.main([__file__, "-v", "--tb=short"])
