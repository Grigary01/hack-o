from engines.map_viz_engine.engine import MapEngine

# Simple test runner without pytest
def run_tests():
    """Run all tests manually"""
    print("Running MapEngine tests...")

    # Test 1: Initialization
    print("Test 1: Initialization")
    center = [55.7522, 37.6156]
    engine = MapEngine(location=center, zoom_start=10)

    assert engine.map is not None, "Map should be initialized"
    assert len(engine.layers) == 0, "Layers should be empty initially"
    assert isinstance(engine.layer_groups, dict), "Layer groups should be a dict"
    assert engine.map.location == center, "Map location should match"
    assert engine.map.options['zoom'] == 10, "Zoom level should match"
    print("✓ Test 1 passed")

    # Test 2: Marker cluster
    print("Test 2: Marker cluster")
    points_data = [
        [55.75, 37.61, "Point 1"],
        [55.76, 37.62, "Point 2"],
        [55.74, 37.63, "Point 3"],
        [55.77, 37.64, "Point 4"]
    ]

    engine.add_marker_cluster(points_data, "Test Points", icon_color='blue')
    assert "Test Points" in engine.layers, "Layer should be added"
    assert len(engine.layers) == 1, "Should have one layer"
    print("✓ Test 2 passed")

    # Test 3: Building markers
    print("Test 3: Building markers")
    building_data = [
        {
            'lat': 55.751,
            'lon': 37.617,
            'type': 'house',
            'name': 'Test House',
            'floors': 2,
            'year_built': 2015,
            'address': '123 Test St'
        },
        {
            'lat': 55.753,
            'lon': 37.619,
            'type': 'office',
            'name': 'Test Office',
            'floors': 10,
            'year_built': 2020,
            'address': '456 Office Ave'
        }
    ]

    engine.add_building_markers(building_data, "Buildings", use_clusters=True)
    assert "Buildings" in engine.layers, "Buildings layer should be added"
    assert len(engine.layers) == 2, "Should have two layers"
    print("✓ Test 3 passed")

    print("All tests passed successfully!")

if __name__ == '__main__':
    run_tests()
