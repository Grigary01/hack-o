#!/usr/bin/env python3
"""
Comprehensive test suite for engine.py module
Tests all functionality with real data and API calls (no mocks)
"""

import pytest
import os
import shutil
from datetime import datetime

# Import the engine module
from engines.map_search_engine.engine import (
    OSMSearchEngine, POI, CityBounds, SearchQuery, CacheEntry,
    SearchMetrics
)

# Test configuration
TEST_CACHE_DIR = "/tmp/test_osm_cache"
TEST_TIMEOUT = 30  # seconds for API calls
TEST_CITY = "Moscow"  # Use a well-known city for testing
TEST_COORDINATES = (55.7558, 37.6176)  # Moscow coordinates


class TestDataClasses:
    """Test all dataclass structures and their methods"""

    def test_poi_creation_and_methods(self):
        """Test POI dataclass creation and methods"""
        from shapely.geometry import Point

        # Test POI creation
        poi = POI(
            id="test_node_123",
            name="Test POI",
            lat=55.7558,
            lon=37.6176,
            tags={"amenity": "restaurant", "name": "Test Restaurant"},
            geometry=Point(37.6176, 55.7558),
            osm_type="node",
            importance_score=2.5,
            search_relevance=1.0,
            category="restaurants",
            subcategory="italian"
        )

        assert poi.id == "test_node_123"
        assert poi.name == "Test POI"
        assert poi.lat == 55.7558
        assert poi.lon == 37.6176
        assert poi.tags["amenity"] == "restaurant"
        assert poi.osm_type == "node"
        assert poi.importance_score == 2.5
        assert poi.search_relevance == 1.0

        # Test to_dict method
        poi_dict = poi.to_dict()
        assert poi_dict["id"] == "test_node_123"
        assert poi_dict["name"] == "Test POI"
        assert poi_dict["lat"] == 55.7558
        assert poi_dict["lon"] == 37.6176
        assert poi_dict["category"] == "restaurants"
        assert "geometry_type" in poi_dict

        # Test from_dict method
        poi_restored = POI.from_dict(poi_dict)
        assert poi_restored.id == poi.id
        assert poi_restored.name == poi.name
        assert poi_restored.lat == poi.lat
        assert poi_restored.lon == poi.lon

    def test_city_bounds_creation_and_methods(self):
        """Test CityBounds dataclass and methods"""
        bounds = CityBounds(
            north=56.0,
            south=55.0,
            east=38.0,
            west=37.0,
            city_name="Moscow",
            country="Russia",
            confidence_score=0.95,
            population=12600000
        )

        assert bounds.north == 56.0
        assert bounds.south == 55.0
        assert bounds.east == 38.0
        assert bounds.west == 37.0
        assert bounds.city_name == "Moscow"
        assert bounds.country == "Russia"
        assert bounds.confidence_score == 0.95
        assert bounds.population == 12600000

        # Test bbox property
        bbox = bounds.bbox
        assert bbox == (55.0, 37.0, 56.0, 38.0)  # (south, west, north, east)

        # Test center property
        center = bounds.center
        assert center == (55.5, 37.5)  # ((north+south)/2, (east+west)/2)

        # Test contains_point method
        assert bounds.contains_point(55.7558, 37.6176)  # Moscow center
        assert not bounds.contains_point(60.0, 30.0)  # St. Petersburg

        # Test calculate_area method
        area = bounds.calculate_area()
        assert area > 0
        assert bounds.area_km2 == area

    def test_search_query_creation_and_methods(self):
        """Test SearchQuery dataclass and methods"""
        search_query = SearchQuery(
            raw_query="restaurants in Moscow",
            parsed_terms=["restaurants", "moscow"],
            categories=["restaurants"],
            location="Moscow",
            bbox=(55.0, 37.0, 56.0, 38.0),
            limit=50,
            radius_km=5.0,
            filters={"cuisine": "italian"},
            intent="search",
            visualization_type="markers",
            analysis_type="general",
            confidence_score=0.9
        )

        assert search_query.raw_query == "restaurants in Moscow"
        assert "restaurants" in search_query.parsed_terms
        assert "restaurants" in search_query.categories
        assert search_query.location == "Moscow"
        assert search_query.limit == 50
        assert search_query.radius_km == 5.0
        assert search_query.filters["cuisine"] == "italian"
        assert search_query.intent == "search"
        assert search_query.confidence_score == 0.9

        # Test to_dict method
        query_dict = search_query.to_dict()
        assert query_dict["raw_query"] == "restaurants in Moscow"
        assert query_dict["categories"] == ["restaurants"]
        assert query_dict["location"] == "Moscow"

    def test_cache_entry_creation_and_methods(self):
        """Test CacheEntry dataclass and methods"""
        test_data = {"test": "data", "timestamp": datetime.now().isoformat()}

        cache_entry = CacheEntry(
            data=test_data,
            timestamp=datetime.now(),
            query_hash="test_hash_123",
            ttl_hours=24,
            access_count=0
        )

        assert cache_entry.data == test_data
        assert cache_entry.query_hash == "test_hash_123"
        assert cache_entry.ttl_hours == 24
        assert cache_entry.access_count == 0
        assert cache_entry.last_accessed is not None

        # Test is_valid method
        assert cache_entry.is_valid()

        # Test mark_accessed method
        original_access_count = cache_entry.access_count
        cache_entry.mark_accessed()
        assert cache_entry.access_count == original_access_count + 1

    def test_search_metrics_creation_and_methods(self):
        """Test SearchMetrics dataclass and methods"""
        metrics = SearchMetrics(
            total_queries=10,
            cache_hits=7,
            cache_misses=3,
            api_requests=8,
            total_response_time=25.5,
            error_count=1,
            last_query_time=2.5
        )

        assert metrics.total_queries == 10
        assert metrics.cache_hits == 7
        assert metrics.cache_misses == 3
        assert metrics.api_requests == 8
        assert metrics.total_response_time == 25.5
        assert metrics.error_count == 1
        assert metrics.last_query_time == 2.5

        # Test cache_hit_rate property
        expected_hit_rate = 70.0  # (7/10) * 100
        assert abs(metrics.cache_hit_rate - expected_hit_rate) < 0.01

        # Test average_response_time property
        expected_avg_time = 2.55  # 25.5 / 10
        assert abs(metrics.average_response_time - expected_avg_time) < 0.01




class TestOSMSearchEngineCore:
    """Test core OSMSearchEngine functionality"""

    @pytest.fixture
    def temp_cache_dir(self):
        """Create temporary cache directory for testing"""
        if os.path.exists(TEST_CACHE_DIR):
            shutil.rmtree(TEST_CACHE_DIR)
        os.makedirs(TEST_CACHE_DIR)
        yield TEST_CACHE_DIR
        # Cleanup after test
        if os.path.exists(TEST_CACHE_DIR):
            shutil.rmtree(TEST_CACHE_DIR)

    def test_engine_initialization(self, temp_cache_dir):
        """Test OSMSearchEngine initialization"""
        engine = OSMSearchEngine(
            cache_dir=temp_cache_dir,
            cache_enabled=True
        )

        assert engine.cache_dir == temp_cache_dir
        assert engine.cache_enabled == True
        assert isinstance(engine.metrics, SearchMetrics)
        assert engine.min_request_interval == 1.0  # OSM_RATE_LIMIT_DELAY

    def test_cache_operations(self, temp_cache_dir):
        """Test cache save and load operations"""
        engine = OSMSearchEngine(cache_dir=temp_cache_dir, cache_enabled=True)

        test_data = {"test_key": "test_value", "numbers": [1, 2, 3]}
        cache_key = "test_cache_key_123"

        # Test save to cache
        engine._save_to_cache(cache_key, test_data, ttl_hours=1)

        # Verify file was created
        cache_file = os.path.join(temp_cache_dir, f"{cache_key}.pkl")
        assert os.path.exists(cache_file)

        # Test load from cache
        loaded_data = engine._load_from_cache(cache_key)
        assert loaded_data == test_data

        # Test cache miss
        miss_data = engine._load_from_cache("nonexistent_key")
        assert miss_data is None

    def test_get_cache_key(self, temp_cache_dir):
        """Test cache key generation"""
        engine = OSMSearchEngine(cache_dir=temp_cache_dir)

        query = "test query"
        params = {"param1": "value1", "param2": 42}

        key1 = engine._get_cache_key(query, params)
        key2 = engine._get_cache_key(query, params)
        key3 = engine._get_cache_key("different query", params)

        # Same inputs should produce same key
        assert key1 == key2
        # Different inputs should produce different keys
        assert key1 != key3

        # Keys should be valid SHA256 hashes (64 characters, hex)
        assert len(key1) == 64
        assert key1.isalnum()

    def test_clear_cache(self, temp_cache_dir):
        """Test cache clearing functionality"""
        engine = OSMSearchEngine(cache_dir=temp_cache_dir, cache_enabled=True)

        # Add some cache entries
        test_data = {"test": "data"}
        for i in range(5):
            cache_key = f"test_key_{i}"
            engine._save_to_cache(cache_key, test_data)

        # Verify files were created
        cache_files = [f for f in os.listdir(temp_cache_dir) if f.endswith('.pkl')]
        assert len(cache_files) == 5

        # Clear cache
        engine.clear_cache()

        # Verify files were removed
        cache_files_after = [f for f in os.listdir(temp_cache_dir) if f.endswith('.pkl')]
        assert len(cache_files_after) == 0

    def test_rate_limiting(self, temp_cache_dir):
        """Test rate limiting functionality"""
        engine = OSMSearchEngine(cache_dir=temp_cache_dir)

        # Test initial state
        assert engine.last_request_time == 0.0
        assert engine.min_request_interval > 0

        # Test rate limit application
        engine._rate_limit()
        first_request_time = engine.last_request_time
        assert first_request_time > 0

        # Test subsequent rate limiting
        engine._rate_limit()
        second_request_time = engine.last_request_time
        assert second_request_time >= first_request_time + engine.min_request_interval


class TestCityCoordinateLookup:
    """Test city coordinate lookup functionality"""

    @pytest.fixture
    def engine(self):
        """Create engine instance for testing"""
        return OSMSearchEngine(cache_enabled=False)  # Disable cache for testing

    def test_city_coordinates_basic_lookup(self, engine):
        """Test basic city coordinate lookup"""
        # Test with a well-known city - specify Russia to get Moscow, Russia not Moscow, Idaho
        coords = engine.get_city_coordinates(TEST_CITY, "Russia")

        if coords:
            lat, lon = coords
            assert isinstance(lat, float)
            assert isinstance(lon, float)
            assert -90 <= lat <= 90
            assert -180 <= lon <= 180

            # Moscow, Russia should be around these coordinates (approximate)
            assert 55.0 <= lat <= 56.5
            assert 37.0 <= lon <= 38.5
        else:
            # If lookup fails, coords should be None
            assert coords is None

    def test_city_coordinates_with_country(self, engine):
        """Test city coordinate lookup with country specification"""
        coords = engine.get_city_coordinates("Paris", "France")

        if coords:
            lat, lon = coords
            assert isinstance(lat, float)
            assert isinstance(lon, float)
            # Paris coordinates (approximate)
            assert 48.0 <= lat <= 49.0
            assert 2.0 <= lon <= 3.0
        else:
            assert coords is None

    def test_city_coordinates_nonexistent_city(self, engine):
        """Test lookup for nonexistent city"""
        coords = engine.get_city_coordinates("NonExistentCity12345")
        # Should return None for nonexistent cities
        assert coords is None

    def test_city_bounds_lookup(self, engine):
        """Test city bounds lookup"""
        bounds = engine.get_city_bounds(TEST_CITY)

        if bounds:
            assert isinstance(bounds, CityBounds)
            assert bounds.city_name == TEST_CITY
            assert isinstance(bounds.north, float)
            assert isinstance(bounds.south, float)
            assert isinstance(bounds.east, float)
            assert isinstance(bounds.west, float)

            # Verify bounds are reasonable
            assert bounds.north > bounds.south
            assert bounds.east > bounds.west

            # If we got Moscow bounds, they should be in a reasonable range
            # (could be Moscow, Russia or Moscow, Idaho - both are valid)
            assert -90 <= bounds.south <= 90
            assert -90 <= bounds.north <= 90
            assert -180 <= bounds.west <= 180
            assert -180 <= bounds.east <= 180
        else:
            assert bounds is None


class TestPOISearch:
    """Test POI search functionality"""

    @pytest.fixture
    def engine(self):
        """Create engine instance for testing"""
        return OSMSearchEngine(cache_enabled=False)

    def test_poi_search_basic(self, engine):
        """Test basic POI search"""
        pois = engine.search_pois("restaurants in Moscow", limit=5)

        assert isinstance(pois, list)
        assert len(pois) <= 5

        if pois:  # Only test if we got results
            for poi in pois:
                assert isinstance(poi, POI)
                assert poi.name
                assert isinstance(poi.lat, float)
                assert isinstance(poi.lon, float)
                assert poi.geometry is not None

    def test_poi_search_with_categories(self, engine):
        """Test POI search with specific categories"""
        search_query = SearchQuery(
            raw_query="hotels and restaurants",
            parsed_terms=["hotels", "restaurants"],
            categories=["hotels", "restaurants"],
            location="Moscow",
            limit=10
        )

        pois = engine.search_pois(search_query)

        assert isinstance(pois, list)
        assert len(pois) <= 10

        if pois:
            for poi in pois:
                assert isinstance(poi, POI)
                # Should have relevant tags
                assert poi.tags

    def test_nearby_pois_search(self, engine):
        """Test nearby POI search"""
        lat, lon = TEST_COORDINATES

        pois = engine.find_nearby_pois(
            lat=lat,
            lon=lon,
            radius_km=1.0,
            categories=["restaurants", "shops"],
            limit=10
        )

        assert isinstance(pois, list)
        assert len(pois) <= 10

        if pois:
            for poi in pois:
                assert isinstance(poi, POI)
                # Verify POI is within radius (approximately)
                from geopy.distance import geodesic
                distance = geodesic((lat, lon), (poi.lat, poi.lon)).km
                assert distance <= 1.5  # Allow some margin for calculation differences

    def test_poi_search_empty_query(self, engine):
        """Test POI search with empty/invalid query"""
        pois = engine.search_pois("")
        assert isinstance(pois, list)
        # Should return empty list or handle gracefully
        assert len(pois) == 0 or all(isinstance(p, POI) for p in pois)


class TestDistanceMatrix:
    """Test distance matrix calculations"""

    @pytest.fixture
    def engine(self):
        """Create engine instance for testing"""
        return OSMSearchEngine(cache_enabled=False)

    def test_distance_matrix_from_coordinates(self, engine):
        """Test distance matrix calculation from coordinates"""
        # Use Moscow center and a few nearby points
        coordinates = [
            (37.6176, 55.7558),  # Moscow center
            (37.6225, 55.7520),  # Nearby point 1
            (37.6127, 55.7597),  # Nearby point 2
        ]

        matrix = engine.calculate_distance_matrix_from_coordinates(coordinates, profile="car")

        if matrix:
            assert matrix["success"] == True
            assert matrix["profile"] == "car"
            assert len(matrix["locations"]) == len(coordinates)
            assert "distances" in matrix
            assert "durations" in matrix
            assert len(matrix["distances"]) == len(coordinates)

            # Check that diagonal is 0 (distance to self)
            for i in range(len(coordinates)):
                assert matrix["distances"][i][i] == 0
        else:
            # If API fails, should return None
            assert matrix is None

    def test_distance_matrix_from_pois(self, engine):
        """Test distance matrix calculation from POI objects"""
        # Create some test POIs
        pois = [
            POI(id="poi1", name="Location 1", lat=55.7558, lon=37.6176, tags={}, geometry=None),
            POI(id="poi2", name="Location 2", lat=55.7520, lon=37.6225, tags={}, geometry=None),
            POI(id="poi3", name="Location 3", lat=55.7597, lon=37.6127, tags={}, geometry=None),
        ]

        matrix = engine.calculate_distance_matrix_from_pois(pois, profile="foot")

        if matrix:
            assert matrix["success"] == True
            assert matrix["profile"] == "foot"
            assert len(matrix["locations"]) == len(pois)
            assert len(matrix["location_names"]) == len(pois)
            assert matrix["location_names"][0] == "Location 1"
        else:
            assert matrix is None

    def test_distance_matrix_invalid_profile(self, engine):
        """Test distance matrix with invalid profile"""
        coordinates = [(37.6176, 55.7558), (37.6225, 55.7520)]

        matrix = engine.calculate_distance_matrix(coordinates, profile="invalid_profile")

        # Should return None for invalid profile
        assert matrix is None

    def test_distance_matrix_empty_locations(self, engine):
        """Test distance matrix with empty locations"""
        matrix = engine.calculate_distance_matrix([])
        assert matrix is None

        matrix = engine.calculate_distance_matrix_from_pois([])
        assert matrix is None


class TestQueryParsing:
    """Test query parsing functionality"""

    @pytest.fixture
    def engine(self):
        """Create engine instance for testing"""
        return OSMSearchEngine(cache_enabled=False)

    def test_parse_search_query_basic(self, engine):
        """Test basic search query parsing"""
        query = "restaurants in Moscow"
        parsed_query = engine.parse_search_query(query)

        assert isinstance(parsed_query, SearchQuery)
        assert parsed_query.raw_query == query
        assert isinstance(parsed_query.parsed_terms, list)
        assert isinstance(parsed_query.categories, list)

    def test_parse_search_query_with_location(self, engine):
        """Test search query parsing with explicit location"""
        query = "hotels near Red Square Moscow"
        parsed_query = engine.parse_search_query(query)

        assert isinstance(parsed_query, SearchQuery)
        assert parsed_query.location is not None or parsed_query.bbox is not None




class TestErrorHandling:
    """Test error handling and edge cases"""

    @pytest.fixture
    def engine(self):
        """Create engine instance for testing"""
        return OSMSearchEngine(cache_enabled=False)

    @pytest.fixture
    def temp_cache_dir(self):
        """Create temporary cache directory for testing"""
        if os.path.exists(TEST_CACHE_DIR):
            shutil.rmtree(TEST_CACHE_DIR)
        os.makedirs(TEST_CACHE_DIR)
        yield TEST_CACHE_DIR
        # Cleanup after test
        if os.path.exists(TEST_CACHE_DIR):
            shutil.rmtree(TEST_CACHE_DIR)

    def test_search_with_invalid_bbox(self, engine):
        """Test search with invalid bounding box"""
        search_query = SearchQuery(
            raw_query="test query",
            parsed_terms=["test"],
            categories=["restaurants"],
            bbox=None,
            location=None
        )

        # Should handle gracefully and use default location
        pois = engine.search_pois(search_query, limit=5)
        assert isinstance(pois, list)

    def test_cache_corruption_handling(self, temp_cache_dir):
        """Test handling of corrupted cache files"""
        engine = OSMSearchEngine(cache_dir=temp_cache_dir, cache_enabled=True)

        # Create a corrupted cache file
        cache_key = "corrupted_key"
        cache_file = os.path.join(temp_cache_dir, f"{cache_key}.pkl")

        with open(cache_file, 'w') as f:
            f.write("This is not a valid pickle file")

        # Try to load corrupted cache
        loaded_data = engine._load_from_cache(cache_key)

        # Should return None and remove corrupted file
        assert loaded_data is None
        assert not os.path.exists(cache_file)

    def test_network_timeout_handling(self, engine):
        """Test handling of network timeouts"""
        # This test is implicit - the engine should handle timeouts gracefully
        # in all network operations, but we can't easily simulate timeouts
        # without mocks. The real test is that the methods don't crash.

        pois = engine.search_pois("restaurants in nonexistent_city_12345", limit=1)
        assert isinstance(pois, list)  # Should return empty list, not crash

    def test_metrics_tracking(self, engine):
        """Test that metrics are properly tracked"""
        initial_queries = engine.metrics.total_queries
        initial_errors = engine.metrics.error_count

        # Perform a search (may succeed or fail)
        pois = engine.search_pois("test query", limit=1)

        # Metrics should be updated
        assert engine.metrics.total_queries >= initial_queries
        # Note: error_count might not increase if search succeeds


class TestPerformanceAndMetrics:
    """Test performance monitoring and metrics"""

    @pytest.fixture
    def engine(self):
        """Create engine instance for testing"""
        return OSMSearchEngine(cache_enabled=True)

    def test_search_metrics_getter(self, engine):
        """Test getting search metrics"""
        metrics = engine.get_search_metrics()

        assert isinstance(metrics, dict)
        required_keys = [
            'total_queries', 'cache_hit_rate', 'cache_hits',
            'cache_misses', 'api_requests', 'average_response_time',
            'error_count', 'error_rate', 'cache_enabled'
        ]

        for key in required_keys:
            assert key in metrics

        assert isinstance(metrics['cache_hit_rate'], float)
        assert 0.0 <= metrics['cache_hit_rate'] <= 100.0

    def test_metrics_calculation_edge_cases(self, engine):
        """Test metrics calculation with edge cases"""
        # Test with zero queries
        metrics = SearchMetrics()
        assert metrics.cache_hit_rate == 0.0
        assert metrics.average_response_time == 0.0

        # Test with some data
        metrics = SearchMetrics(
            total_queries=10,
            cache_hits=7,
            cache_misses=3,
            total_response_time=50.0
        )

        assert metrics.cache_hit_rate == 70.0
        assert metrics.average_response_time == 5.0


def run_specific_test():
    """Run a specific test to verify functionality"""
    print("Running specific functionality test...")

    # Test basic engine creation and search
    engine = OSMSearchEngine(cache_enabled=False)

    print("Testing basic POI search...")
    pois = engine.search_pois("restaurants in Moscow", limit=3)

    print(f"Found {len(pois)} POIs")
    if pois:
        for poi in pois:
            print(f"- {poi.name} (lat: {poi.lat:.4f}, lon: {poi.lon:.4f})")

    print("Testing distance matrix...")
    coordinates = [
        (37.6176, 55.7558),  # Moscow center
        (37.6225, 55.7520),  # Nearby
    ]

    matrix = engine.calculate_distance_matrix_from_coordinates(coordinates)
    if matrix:
        print("Distance matrix calculated successfully")
        print(f"Profile: {matrix['profile']}")
        print(f"Locations: {len(matrix['locations'])}")
    else:
        print("Distance matrix calculation failed (likely due to API unavailability)")

    print("Testing city coordinates lookup...")
    coords = engine.get_city_coordinates("Moscow")
    if coords:
        print(f"Moscow coordinates: {coords}")
    else:
        print("City coordinates lookup failed")

    print("All basic functionality tests completed!")


if __name__ == "__main__":
    # Run the specific test first
    run_specific_test()

    # Then run pytest
    pytest.main([__file__, "-v", "--tb=short"])
